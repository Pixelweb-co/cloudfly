# 🧠 Base de Conocimiento y Lecciones Aprendidas (Memoria Scrum Team)

Este archivo registra errores históricos y lecciones aprendidas para que el equipo autónomo de IA aprenda de ejecuciones previas y nunca repita los mismos fallos técnicos.

---

## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:03:05) - Área: CrewExecution
*   **Fallo Detectado**: `litellm.RateLimitError: RateLimitError: GroqException - {"error":{"message":"Request too large for model `llama-3.3-70b-versatile` in organization `org_01ksde2magfx3t9xkgqzbqg29c` service tier `on_demand` on tokens per minute (TPM): Limit 12000, Requested 16417, please reduce your message size and try again. Need more tokens? Upgrade to Dev Tier today at https://console.groq.com/settings/billing","type":"tokens","code":"rate_limit_exceeded"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.



## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:03:36) - Área: CrewExecution
*   **Fallo Detectado**: `litellm.RateLimitError: RateLimitError: GroqException - {"error":{"message":"Request too large for model `llama-3.3-70b-versatile` in organization `org_01ksde2magfx3t9xkgqzbqg29c` service tier `on_demand` on tokens per minute (TPM): Limit 12000, Requested 16663, please reduce your message size and try again. Need more tokens? Upgrade to Dev Tier today at https://console.groq.com/settings/billing","type":"tokens","code":"rate_limit_exceeded"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.



## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:04:08) - Área: CrewExecution
*   **Fallo Detectado**: `litellm.RateLimitError: RateLimitError: GroqException - {"error":{"message":"Request too large for model `llama-3.3-70b-versatile` in organization `org_01ksde2magfx3t9xkgqzbqg29c` service tier `on_demand` on tokens per minute (TPM): Limit 12000, Requested 16910, please reduce your message size and try again. Need more tokens? Upgrade to Dev Tier today at https://console.groq.com/settings/billing","type":"tokens","code":"rate_limit_exceeded"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.



## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:04:39) - Área: CrewExecution
*   **Fallo Detectado**: `litellm.RateLimitError: RateLimitError: GroqException - {"error":{"message":"Request too large for model `llama-3.3-70b-versatile` in organization `org_01ksde2magfx3t9xkgqzbqg29c` service tier `on_demand` on tokens per minute (TPM): Limit 12000, Requested 17158, please reduce your message size and try again. Need more tokens? Upgrade to Dev Tier today at https://console.groq.com/settings/billing","type":"tokens","code":"rate_limit_exceeded"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.



## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:05:11) - Área: CrewExecution
*   **Fallo Detectado**: `litellm.RateLimitError: RateLimitError: GroqException - {"error":{"message":"Request too large for model `llama-3.3-70b-versatile` in organization `org_01ksde2magfx3t9xkgqzbqg29c` service tier `on_demand` on tokens per minute (TPM): Limit 12000, Requested 17404, please reduce your message size and try again. Need more tokens? Upgrade to Dev Tier today at https://console.groq.com/settings/billing","type":"tokens","code":"rate_limit_exceeded"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:07:59) - Área: CrewExecution
*   **Fallo Detectado**: `litellm.RateLimitError: RateLimitError: GroqException - {"error":{"message":"Request too large for model `llama-3.3-70b-versatile` in organization `org_01ksde2magfx3t9xkgqzbqg29c` service tier `on_demand` on tokens per minute (TPM): Limit 12000, Requested 14984, please reduce your message size and try again. Need more tokens? Upgrade to Dev Tier today at https://console.groq.com/settings/billing","type":"tokens","code":"rate_limit_exceeded"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:08:38) - Área: CrewExecution
*   **Fallo Detectado**: `litellm.RateLimitError: RateLimitError: GroqException - {"error":{"message":"Request too large for model `llama-3.3-70b-versatile` in organization `org_01ksde2magfx3t9xkgqzbqg29c` service tier `on_demand` on tokens per minute (TPM): Limit 12000, Requested 14628, please reduce your message size and try again. Need more tokens? Upgrade to Dev Tier today at https://console.groq.com/settings/billing","type":"tokens","code":"rate_limit_exceeded"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:09:14) - Área: CrewExecution
*   **Fallo Detectado**: `litellm.RateLimitError: RateLimitError: GroqException - {"error":{"message":"Request too large for model `llama-3.3-70b-versatile` in organization `org_01ksde2magfx3t9xkgqzbqg29c` service tier `on_demand` on tokens per minute (TPM): Limit 12000, Requested 14629, please reduce your message size and try again. Need more tokens? Upgrade to Dev Tier today at https://console.groq.com/settings/billing","type":"tokens","code":"rate_limit_exceeded"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:13:35) - Área: CrewExecution-CLOUD-178
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Implement Enlace Directo en el Mensaje\", \"description\": \"\\u2705 **Product Owner**: El cuerpo del mensaje de WhatsApp debe contener un enlace al chat directo del contacto en el dashboard, ej: `https://dashboard.cloudfly.com.co/contacts/{contactId}`. Acceptance Criteria: * El sistema incluye un enlace al chat directo del contacto en el dashboard en el cuerpo del mensaje de WhatsApp. * El sistema env\\u00eda el mensaje con el enlace al chat directo.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:14:26) - Área: CrewExecution-CLOUD-177
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Implement Obtención de Teléfono (JOIN) for CLOUD-177\", \"description\": \"🤖 **Product Owner**: Implement the Obtención de Teléfono (JOIN) feature as described in CLOUD-177. The goal is to obtain the phone number of advisors/administrators through a JOIN with the contacts table via the users.contact_id = contacts.id field. Acceptance Criteria: * The system obtains the phone number of advisors/administrators via a JOIN with the contacts table. * The system identifies the phone number of advisors/administrators. The developer should focus on implementing the necessary database queries and ensuring the data is correctly retrieved and displayed.\", \"issue_type\": \"Task\", \"project_key\": \"CLOUD\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:15:20) - Área: CrewExecution-CLOUD-176
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Implement Kafka notification-service\", \"description\": \"\\u2705 **Product Owner**: The system must publish a JSON structured message (DTO `NotificationMessage`) to the Kafka topic `whatsapp-notifications`. The system must channel the notification through Kafka. Acceptance Criteria: * The system publishes a JSON structured message (DTO `NotificationMessage`) to the Kafka topic `whatsapp-notifications`. * The system channels the notification through Kafka.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:16:18) - Área: CrewExecution-CLOUD-175
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Investigate and document the current implementation of notification-service\", \"description\": \"\\u2705 **Product Owner**: Investigate the current implementation of notification-service and document how it consumes messages, searches for the corresponding WhatsApp instance, and sends messages. The goal is to understand the existing workflow and identify potential areas for improvement. Acceptance Criteria: * A detailed document describing the current implementation of notification-service * A list of potential areas for improvement\", \"project_key\": \"CLOUD\", \"issue_type\": \"Sub-task\", \"parent_key\": \"CLOUD-175\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:17:10) - Área: CrewExecution-CLOUD-174
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Identificaci\\u00f3n de Asesores (Asignados)\", \"description\": \"\\u00a1\\u2122 **Product Owner**: Al dispararse la transferencia (`transfer_to_human`), el sistema debe leer el campo `assigned_user_ids` del contacto en la tabla `contacts`. Acceptance Criteria: * El sistema lee el campo `assigned_user_ids` del contacto en la tabla `contacts`. * El sistema identifica los asesores asignados al contacto.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:18:03) - Área: CrewExecution-CLOUD-173
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Identificaci\\u00f3n de Fallback (Admin)\", \"description\": \"\\u00a1\\u00a1\\u00a1 **Product Owner**: Si el contacto no tiene usuarios asignados (`assigned_user_ids` est\\u00e1 vac\\u00edo o nulo), el sistema debe buscar en la base de datos a los usuarios que tengan el rol de *Administrador* (`role_name = 'ADMIN'` con ID `2` o `MANAGER` con ID `3`) para el Tenant correspondiente. Acceptance Criteria: * El sistema busca en la base de datos a los usuarios que tengan el rol de *Administrador* (`role_name = 'ADMIN'` con ID `2` o `MANAGER` con ID `3`) para el Tenant correspondiente. * El sistema identifica el administrador del tenant.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:19:03) - Área: CrewExecution-CLOUD-172
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Notificación de Transferencia Humana por WhatsApp a Asesores o Administradores\", \"description\": \"🤖 **Product Owner**: Cuando el Agente de IA realiza una transferencia a un asesor humano (`transfer_to_human` o handoff), el sistema debe notificar por WhatsApp a los asesores asignados a ese contacto. Si el contacto no tiene asesores asignados, la notificación se enviará al usuario con el rol de Administrador (`ADMIN` con ID `2` o `MANAGER` con ID `3` como fallback) de ese Tenant. El mensaje se enviará usando la instancia de WhatsApp del tenant asociada a la `companyId = 1`, publicando el payload estructurado en la cola de Kafka `whatsapp-notifications` para ser consumido y despachado por el `notification-service` (Java). Acceptance Criteria: * La notificación se publica en Kafka y es consumida por `notification-service`. * La notificación se envía al asesor asignado o al administrador del tenant.\", \"issue_type\": \"Task\", \"project_key\": \"CLOUD\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:19:56) - Área: CrewExecution-CLOUD-171
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Test Implementation of Pending Tasks\", \"description\": \"\\u2705 **Product Owner**: Test the implementation of the pending tasks to ensure it meets the acceptance criteria. The testing should include the following: 1. Test the implementation to ensure it meets the acceptance criteria 2. Identify and fix any errors or bugs in the implementation. Acceptance Criteria: * The implementation is tested to ensure it meets the acceptance criteria * Any errors or bugs in the implementation are fixed\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:20:47) - Área: CrewExecution-CLOUD-170
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Complete and close ticket CLOUD-170: 'Test Issue'\", \"description\": \"\\u2705 **Product Owner**: This task is to complete and close the existing ticket CLOUD-170. The acceptance criteria are: * The task is completed according to the specifications and requirements. * The issue is closed in Jira.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:23:28) - Área: CrewExecution-CLOUD-178
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Implement Enlace Directo en el Mensaje\", \"description\": \"🤖 **Product Owner**: El cuerpo del mensaje de WhatsApp debe contener un enlace al chat directo del contacto en el dashboard, ej: `https://dashboard.cloudfly.com.co/contacts/{contactId}`. Acceptance Criteria: * El sistema incluye un enlace al chat directo del contacto en el dashboard en el cuerpo del mensaje de WhatsApp. * El sistema env\\u00eda el mensaje con el enlace al chat directo.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:24:22) - Área: CrewExecution-CLOUD-177
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Implement Obtención de Teléfono (JOIN) for CLOUD-177\", \"description\": \"🤖 **Product Owner**: Implement the Obtención de Teléfono (JOIN) feature as described in CLOUD-177. The system must obtain the phone number of advisors/administrators through a JOIN with the contacts table via the users.contact_id = contacts.id field. Acceptance Criteria: * The system obtains the phone number of advisors/administrators via a JOIN with the contacts table. * The system identifies the phone number of advisors/administrators.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:25:21) - Área: CrewExecution-CLOUD-176
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"tool call validation failed: attempted to call tool 'create_jira_issue={\"summary\": \"Research Kafka notification-service\", \"description\": \"\\u2705 **Product Owner**: Investigate how to integrate Kafka with the notification-service. Research the necessary dependencies, configurations, and potential challenges. Acceptance Criteria: * A detailed report on the feasibility of integrating Kafka with the notification-service. * A list of required dependencies and configurations.\", \"issue_type\": \"Sub-task\", \"parent_key\": \"CLOUD-176\"}' which was not in request.tools","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue={\"summary\": \"Research Kafka notification-service\", \"description\": \"\\u2705 **Product Owner**: Investigate how to integrate Kafka with the notification-service. Research the necessary dependencies, configurations, and potential challenges. Acceptance Criteria: * A detailed report on the feasibility of integrating Kafka with the notification-service. * A list of required dependencies and configurations.\", \"issue_type\": \"Sub-task\", \"parent_key\": \"CLOUD-176\"}\u003e\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:26:15) - Área: CrewExecution-CLOUD-175
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Investigar y configurar la seleccion automatica de instancia de WhatsApp\", \"description\": \"🤖 **Product Owner**: Investigar y configurar la seleccion automatica de instancia de WhatsApp. Acceptance Criteria: * El sistema selecciona automáticamente la instancia de WhatsApp correspondiente al `tenantId` y `companyId = 1`. * El sistema envía el mensaje exitosamente. Se debe investigar y configurar la seleccion automatica de instancia de WhatsApp para que se ajuste a los requisitos del sistema.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Sub-task\", \"parent_key\": \"CLOUD-175\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:27:11) - Área: CrewExecution-CLOUD-174
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"tool call validation failed: parameters for tool create_jira_issue did not match schema: errors: [missing properties: 'parent_key']","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue\u003e{\"summary\": \"Identificaci\\u00f3n de Asesores (Asignados)\", \"description\": \"\\u00a1\\u2122 **Product Owner**: Al dispararse la transferencia (`transfer_to_human`), el sistema debe leer el campo `assigned_user_ids` del contacto en la tabla `contacts`. Acceptance Criteria: * El sistema lee el campo `assigned_user_ids` del contacto en la tabla `contacts`. * El sistema identifica los asesores asignados al contacto.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\"}\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:28:03) - Área: CrewExecution-CLOUD-173
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Implement Fallback Identification for Admin\", \"description\": \"\\u2705 **Product Owner**: The system must search the database for users with the 'ADMIN' role (ID 2) or 'MANAGER' role (ID 3) for the corresponding Tenant when the contact has no assigned users (assigned_user_ids is empty or null). Acceptance Criteria: * The system searches the database for users with the 'ADMIN' role (ID 2) or 'MANAGER' role (ID 3) for the corresponding Tenant. * The system identifies the administrator of the tenant.\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.


## 🔄 Autocorrección y Aprendizaje Continuo (2026-05-25 16:28:59) - Área: CrewExecution-CLOUD-172
*   **Fallo Detectado**: `litellm.BadRequestError: GroqException - {"error":{"message":"Failed to call a function. Please adjust your prompt. See 'failed_generation' for more details.","type":"invalid_request_error","code":"tool_use_failed","failed_generation":"\u003cfunction=create_jira_issue({\"summary\": \"Complete and close ticket CLOUD-172: 'CLOUD-158: Notificación de Transferencia Humana por WhatsApp a Asesores o Administradores'\", \"description\": \"🤖 **Product Owner**: The task is to complete and close the existing ticket CLOUD-172. This involves implementing the notification feature for human transfer to advisors or administrators via WhatsApp. The acceptance criteria for this task include publishing the notification in Kafka and consuming it via the notification-service, as well as sending the notification to the assigned advisor or administrator. The developer should ensure that the payload is strictly structured in JSON format and includes all required fields. The Evolution API requires a minimum delay of 3 seconds between WhatsApp message sends and simulation of presence 'composing' to avoid spam blocks. The task should be completed based on the provided codebase context and the specifications outlined in the technical specification document (spec.md).\", \"project_key\": \"CLOUD\", \"issue_type\": \"Task\", \"parent_key\": \"\"})\u003c/function\u003e\n"}}
`
*   **Lección y Acción Correctiva**: Cuando ocurra este error, el equipo debe re-evaluar la sintaxis o variables en juego, limpiar el búfer de rate limits, rotar las claves del pool de OpenRouter de inmediato y simplificar el volumen de datos consultado para reducir la carga de tokens.
