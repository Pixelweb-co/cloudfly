import requests

url = "https://openrouter.ai/api/v1/models"
response = requests.get(url).json()

free_models = []
gemini_models = []
for model in response.get("data", []):
    pricing = model.get("pricing", {})
    model_id = model.get("id")
    if pricing.get("prompt") == "0" and pricing.get("completion") == "0":
        free_models.append(model_id)
    if "gemini" in model_id.lower():
        gemini_models.append(model_id)

print("Free Models on OpenRouter:")
for m in sorted(free_models):
    print("-", m)

print("\nGemini Models on OpenRouter:")
for m in sorted(gemini_models):
    print("-", m)
