import os
from crewai import LLM

# Let's test the key from test_llm.py
gemini_key = "AIzaSyDahQxleQFoDHouFrOuj5cN0b2GVpaV_DE"
os.environ["GEMINI_API_KEY"] = gemini_key

print("Testing Gemini LLM with gemini/gemini-1.5-flash...")
try:
    llm = LLM(
        model="gemini/gemini-1.5-flash",
        api_key=gemini_key,
        temperature=0.2
    )
    response = llm.call(messages=[{"role": "user", "content": "Dí hola y di qué modelo eres."}])
    print("Success Gemini:", response)
except Exception as e:
    print("Error Gemini:", e)
