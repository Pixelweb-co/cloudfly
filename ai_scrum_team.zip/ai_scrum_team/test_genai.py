import os
from google import genai

client = genai.Client(api_key=os.environ.get("GOOGLE_API_KEY", "AIzaSyDZMuMM7UjwRujrZPlXygh6HAJuBiin6UI"))
try:
    print("Testing gemini-1.5-pro...")
    response = client.models.generate_content(
        model='gemini-1.5-pro',
        contents='Hello'
    )
    print("Success:", response.text)
except Exception as e:
    print("Error:", e)

try:
    print("Testing gemini-1.5-pro-002...")
    response = client.models.generate_content(
        model='gemini-1.5-pro-002',
        contents='Hello'
    )
    print("Success:", response.text)
except Exception as e:
    print("Error:", e)
