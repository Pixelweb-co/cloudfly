import os
from dotenv import load_dotenv
from crewai import LLM

load_dotenv(dotenv_path=r"c:\apps\cloudfly\ai_scrum_team\.env")

print("GROQ_API_KEY present:", bool(os.getenv("GROQ_API_KEY")))

try:
    llm = LLM(
        model="groq/llama-3.1-8b-instant",
        api_key=os.getenv("GROQ_API_KEY"),
        temperature=0.2
    )
    response = llm.call(messages=[{"role": "user", "content": "Dí hola y di qué modelo eres."}])
    print("Success Groq 8B:", response)
except Exception as e:
    print("Error Groq 8B:", e)
