import os
import json
import pytest
from fastapi.testclient import TestClient
from ai_scrum_team.handoff_endpoint import router

# Create a minimal FastAPI app for testing
from fastapi import FastAPI
app = FastAPI()
app.include_router(router, prefix="/ia_scrum_team")

client = TestClient(app)

@pytest.fixture(autouse=True)
def set_env(monkeypatch):
    # Set required env vars for the endpoint
    monkeypatch.setenv("HANDOFF_AUTH_TOKEN", "secret-token")
    monkeypatch.setenv("AI_AGENT_URL", "http://localhost:9999/handoff")
    monkeypatch.setenv("AI_AGENT_TOKEN", "agent-token")

# Mock the external AI agent using a simple local server in the test
from http.server import BaseHTTPRequestHandler, HTTPServer
import threading

class MockAgentHandler(BaseHTTPRequestHandler):
    def do_POST(self):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length)
        data = json.loads(body)
        # Simple validation
        if "ticket_id" not in data:
            self.send_response(400)
            self.end_headers()
            return
        self.send_response(200)
        self.end_headers()
        self.wfile.write(b"{\"status\":\"ok\"}")

    def log_message(self, format, *args):
        return

# Start mock server in background
mock_server = HTTPServer(("localhost", 9999), MockAgentHandler)
thread = threading.Thread(target=mock_server.serve_forever, daemon=True)
thread.start()

def test_handoff_success():
    payload = {
        "ticket_id": "CLOUD-123",
        "user_id": "user1",
        "context": {"foo": "bar"},
        "priority": 3
    }
    headers = {"X-Auth-Token": "secret-token"}
    response = client.post("/ia_scrum_team/handoff", json=payload, headers=headers)
    assert response.status_code == 202
    assert response.json() == {"status": "queued", "ticket_id": "CLOUD-123"}

def test_handoff_unauthorized():
    payload = {"ticket_id": "CLOUD-123", "user_id": "user1"}
    response = client.post("/ia_scrum_team/handoff", json=payload)
    assert response.status_code == 401

# Clean up mock server after tests
@pytest.fixture(scope="session", autouse=True)
def shutdown_mock_server():
    yield
    mock_server.shutdown()
