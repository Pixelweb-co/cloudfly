import os
from langchain_community.utilities.jira import JiraAPIWrapper

os.environ["JIRA_CLOUD"] = "True"
os.environ["JIRA_INSTANCE_URL"] = "https://healty.atlassian.net"
os.environ["JIRA_USERNAME"] = "egbmaster2007@gmail.com"
os.environ["JIRA_API_TOKEN"] = "ATATT3xFfGF0EVrQZwoGmUAPsmX5vOyM5uK8VLeDCa0kBoDRw2V0EzHkbNhUqXo4GR0Z4BAl_kqLek60PHmbYzYExO3tP6r3eu3enjdQNYZBzPS7UCItFk7ao6Sz30Bv407r8Hos7TAEu342LeajnkH-IoP14xLhHkroi82esAIF5mClfOAoMKo=77F4F73C"

wrapper = JiraAPIWrapper()

try:
    print("Testing Jira Connection...")
    # Try to list projects
    projects = wrapper.jira.projects()
    print("Available Projects:")
    for p in projects:
        print(f" - {p.get('key')}: {p.get('name')}")
        
    print("\nAttempting to create a test issue in CLOUD...")
    query = '{"summary": "Test Issue", "description": "This is a test from python", "project": {"key": "CLOUD"}, "issuetype": {"name": "Task"}}'
    result = wrapper.run("create_issue", query)
    print("Result:", result)
except Exception as e:
    print("Jira Error:", e)
