import os
from dotenv import load_dotenv
load_dotenv(dotenv_path=r"c:\apps\cloudfly\ai_scrum_team\.env")

from tools import jira_wrapper

if not jira_wrapper:
    print("Jira wrapper not loaded.")
    exit(1)

print("Testing JQL run...")
try:
    # Run a test query
    res = jira_wrapper.run("jql", "project = CLOUD AND status != Done")
    print("Type of response:", type(res))
    print("Response preview:", res[:500] if res else "None")
except Exception as e:
    print("Error:", e)
