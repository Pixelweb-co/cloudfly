import os
from litellm import completion

os.environ["GEMINI_API_KEY"] = "AIzaSyDZMuMM7UjwRujrZPlXygh6HAJuBiin6UI"

try:
    print("Testing Litellm with gemini/gemini-1.5-flash...")
    response = completion(
        model="gemini/gemini-1.5-flash", 
        messages=[{"role": "user", "content": "Hello"}]
    )
    print("Success:", response.choices[0].message.content)
except Exception as e:
    print("Error:", e)
