import os
from crewai import LLM

os.environ["GEMINI_API_KEY"] = "AIzaSyDahQxleQFoDHouFrOuj5cN0b2GVpaV_DE"

def test_model(model_name):
    print(f"Testing {model_name}...")
    try:
        llm = LLM(model=model_name)
        response = llm.call(messages=[{"role": "user", "content": "Hello"}])
        print("Success:", response)
    except Exception as e:
        print("Error:", e)

test_model("gemini-1.5-flash")
test_model("gemini/gemini-1.5-flash")
test_model("gemini/models/gemini-1.5-flash")
