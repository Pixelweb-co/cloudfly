from crewai import LLM

print("Testing local Qwen 2.5 Coder via Ollama...")
try:
    llm = LLM(
        model="ollama/qwen2.5-coder:7b",
        base_url="http://localhost:11434",
        temperature=0.0
    )
    response = llm.call(messages=[{"role": "user", "content": "Dí hola en español y confirma tu nombre de modelo."}])
    print("Success Local Qwen:", response)
except Exception as e:
    print("Error Local Qwen:", e)
