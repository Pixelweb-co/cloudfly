import os
import sys
from dotenv import load_dotenv
from crewai import LLM

sys.stdout.reconfigure(encoding='utf-8')
load_dotenv(dotenv_path=r"c:\apps\cloudfly\ai_scrum_team\.env")

print("OPENAI_API_KEY present:", bool(os.getenv("OPENAI_API_KEY")))

try:
    llm = LLM(
        model="openai/gpt-4o-mini",
        api_key=os.getenv("OPENAI_API_KEY"),
        temperature=0.2
    )
    response = llm.call(messages=[{"role": "user", "content": "Dí hola en español."}])
    print("Success OpenAI GPT-4o-mini:", response)
except Exception as e:
    print("Error OpenAI GPT-4o-mini:", e)
