import os
from dotenv import load_dotenv
from crewai import LLM

# Load environment variables
load_dotenv(dotenv_path=r"c:\apps\cloudfly\ai_scrum_team\.env")

print("OPENAI_API_KEY present:", bool(os.getenv("OPENAI_API_KEY")))
print("GROQ_API_KEY present:", bool(os.getenv("GROQ_API_KEY")))

def test_llm(name, llm_instance):
    print(f"\n--- Testing LLM: {name} ---")
    try:
        response = llm_instance.call(messages=[{"role": "user", "content": "Dí hola y di qué modelo eres."}])
        print(f"Success {name}:", response)
        return True
    except Exception as e:
        print(f"Error {name}:", e)
        return False

# Initialize test instances exactly like agents.py
try:
    openai_llm = LLM(
        model="gpt-4o",
        api_key=os.getenv("OPENAI_API_KEY"),
        temperature=0.2
    )
    test_llm("openai_llm", openai_llm)
except Exception as e:
    print("Error creating OpenAI LLM:", e)

try:
    groq_llm = LLM(
        model="groq/llama-3.3-70b-versatile",
        api_key=os.getenv("GROQ_API_KEY"),
        temperature=0.2
    )
    test_llm("groq_llm", groq_llm)
except Exception as e:
    print("Error creating Groq LLM:", e)
