import os
from dotenv import load_dotenv
from crewai import LLM

load_dotenv(dotenv_path=r"c:\apps\cloudfly\ai_scrum_team\.env")

print("OPENROUTER_API_KEY present:", bool(os.getenv("OPENROUTER_API_KEY")))

try:
    llm = LLM(
        model="openrouter/google/gemini-2.5-flash:free",
        base_url="https://openrouter.ai/api/v1",
        api_key=os.getenv("OPENROUTER_API_KEY"),
        temperature=0.2
    )
    response = llm.call(messages=[{"role": "user", "content": "Dí hola y di qué modelo eres."}])
    print("Success OpenRouter Gemini:", response)
except Exception as e:
    print("Error OpenRouter Gemini:", e)
