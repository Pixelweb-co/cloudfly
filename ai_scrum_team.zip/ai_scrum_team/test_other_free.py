import os
import sys
from dotenv import load_dotenv
from crewai import LLM

sys.stdout.reconfigure(encoding='utf-8')
load_dotenv(dotenv_path=r"c:\apps\cloudfly\ai_scrum_team\.env")

print("OPENROUTER_API_KEY present:", bool(os.getenv("OPENROUTER_API_KEY")))

def try_model(model_name):
    print(f"\nTesting OpenRouter with {model_name}...")
    try:
        llm = LLM(
            model=model_name,
            base_url="https://openrouter.ai/api/v1",
            api_key=os.getenv("OPENROUTER_API_KEY"),
            temperature=0.2
        )
        response = llm.call(messages=[{"role": "user", "content": "Dí hola en español."}])
        print(f"Success {model_name}:", response)
        return True
    except Exception as e:
        print(f"Error {model_name}:", e)
        return False

try_model("openrouter/meta-llama/llama-3.2-3b-instruct:free")
try_model("openrouter/google/gemma-4-31b-it:free")
