import os
import sys
from dotenv import load_dotenv
from crewai import LLM

sys.stdout.reconfigure(encoding='utf-8')
load_dotenv(dotenv_path=r"c:\apps\cloudfly\ai_scrum_team\.env")

print("OPENROUTER_API_KEY present:", bool(os.getenv("OPENROUTER_API_KEY")))

try:
    llm = LLM(
        model="openrouter/openrouter/owl-alpha",
        base_url="https://openrouter.ai/api/v1",
        api_key=os.getenv("OPENROUTER_API_KEY"),
        temperature=0.2
    )
    response = llm.call(messages=[{"role": "user", "content": "Dí hola en español y di quién eres."}])
    print("Success Owl Alpha:", response)
except Exception as e:
    print("Error Owl Alpha:", e)
