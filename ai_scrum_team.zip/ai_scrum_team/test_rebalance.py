import os
import sys
import time
import threading
from dotenv import load_dotenv

# Asegurar encoding UTF-8 en consola Windows
if hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8')

# Cargar variables de entorno
load_dotenv()

# Asegurar entorno de Jira
os.environ["JIRA_CLOUD"] = "True"

from connector import ScrumConnector
from main import check_pending_jira_tasks
from tools import jira_wrapper

def run_simulation():
    print("==================================================")
    print("🧪 SIMULADOR DE BALANCEO DINÁMICO (WORK-STEALING)")
    print("==================================================")

    # 1. Conectar Master de prueba
    print("\n[🔌 Paso 1]: Iniciando y conectando Master...")
    master = ScrumConnector(instance_id="sim_master")
    if not master.connect():
        print("❌ Error: No se pudo conectar a Redis. Asegúrate de que el contenedor de Redis esté activo.")
        return
    
    # Limpiar estado previo de la simulación en Redis para un test reproducible
    master.redis_client.delete("scrum:master")
    master.redis_client.delete("scrum:workers")
    master.redis_client.delete("scrum:backlog_empty")
    for k in master.redis_client.scan_iter("scrum:queue:*"):
        master.redis_client.delete(k)
    for k in master.redis_client.scan_iter("scrum:task:*"):
        master.redis_client.delete(k)
    for k in master.redis_client.scan_iter("scrum:active_task:*"):
        master.redis_client.delete(k)
    for k in master.redis_client.scan_iter("scrum:heartbeat:*"):
        master.redis_client.delete(k)
        
    master.elect_master()
    print(f"👑 Rol de sim_master es Master: {master.is_master}")

    # Hilo para que el Master escuche los eventos Pub/Sub
    def listen_master():
        pubsub = master.redis_client.pubsub()
        pubsub.subscribe("scrum:events")
        print("📡 Master: Hilo de eventos activo y escuchando...")
        for message in pubsub.listen():
            if message['type'] == 'message':
                import json
                data = json.loads(message['data'])
                print(f"📡 [Master PubSub] Evento recibido -> {data['event_type']}: {data['message']}")
                if data.get('event_type') == 'worker_connected':
                    print("\n⚡ [Master PubSub] ¡Conexión detectada! Ejecutando rebalance_tasks()...")
                    master.rebalance_tasks()
                    
    t_master = threading.Thread(target=listen_master, daemon=True)
    t_master.start()
    time.sleep(1)

    # 2. Consultar Jira para obtener tareas reales
    print("\n[🔌 Paso 2]: Consultando Jira para obtener tickets pendientes...")
    issues = check_pending_jira_tasks()
    task_ids = [issue.get('key') for issue in issues]
    
    if not task_ids:
        print("⚠️ No hay tareas pendientes en Jira (proyecto CLOUD). Creando una tarea de prueba en Jira...")
        try:
            if jira_wrapper and hasattr(jira_wrapper, 'run'):
                import json
                payload = {
                    "summary": "Tarea de Prueba para Rebalanceo",
                    "description": "Creada automáticamente por el script de simulación de balanceo dinámico.",
                    "project": {"key": "CLOUD"},
                    "issuetype": {"name": "Task"}
                }
                res = jira_wrapper.run("create_issue", json.dumps(payload))
                print(f"✅ Tarea de prueba creada en Jira: {res}")
                # Re-consultar Jira
                issues = check_pending_jira_tasks()
                task_ids = [issue.get('key') for issue in issues]
        except Exception as e:
            print(f"❌ Error al crear tarea de prueba: {e}")
            
    # Si sigue sin haber tareas reales, usamos mocks locales para la simulación
    if not task_ids:
        print("⚠️ Usando IDs de tarea simulados (CLOUD-101, CLOUD-102, CLOUD-103) para continuar la prueba...")
        task_ids = ["CLOUD-101", "CLOUD-102", "CLOUD-103"]

    print(f"📋 Tareas para la simulación: {task_ids}")

    # 3. Registrar al Worker 1 y asignarle múltiples tareas (Sobreasignación)
    print("\n[🔌 Paso 3]: Registrando al Worker 1 ('sim_worker_1') y enviándole 3 tareas...")
    worker1 = ScrumConnector(instance_id="sim_worker_1")
    worker1.connect()
    worker1.redis_client.sadd("scrum:workers", "sim_worker_1")
    # Simular latido vivo
    worker1.redis_client.set("scrum:heartbeat:sim_worker_1", "alive", ex=10)

    # El Master le asigna y encola 3 tareas al Worker 1
    for task_id in task_ids[:3]:
        master.send_task("sim_worker_1", task_id)
        
    print(f"📊 Cola de sim_worker_1 actual: {master.redis_client.lrange('scrum:queue:sim_worker_1', 0, -1)}")

    time.sleep(2)

    # 4. Registrar al Worker 2 (Conexión dinámica)
    print("\n[🔌 Paso 4]: Conectando y registrando al Worker 2 ('sim_worker_2')...")
    print("(Esto publicará el evento 'worker_connected' y disparará el balanceo automático en el Master)")
    
    worker2 = ScrumConnector(instance_id="sim_worker_2")
    worker2.connect()
    # Simular latido vivo
    worker2.redis_client.set("scrum:heartbeat:sim_worker_2", "alive", ex=10)
    
    # elect_master() en sim_worker_2 registrará al worker y publicará el evento
    worker2.elect_master()

    # Esperar un momento para que ocurra el balanceo en el hilo secundario
    time.sleep(3)

    # 5. Revisar resultados del balanceo
    print("\n[🔌 Paso 5]: Verificando estado final de colas...")
    q1 = master.redis_client.lrange("scrum:queue:sim_worker_1", 0, -1)
    q2 = master.redis_client.lrange("scrum:queue:sim_worker_2", 0, -1)
    
    print(f"📊 Cola final de sim_worker_1: {q1}")
    print(f"📊 Cola final de sim_worker_2: {q2}")

    if len(q2) > 0:
        print("\n✅ ¡PRUEBA EXITOSA! El Master detectó la conexión de sim_worker_2 y le rebalanceó/robó tareas de la cola de sim_worker_1 automáticamente.")
    else:
        print("\n❌ PRUEBA FALLIDA. Las tareas no se rebalancearon correctamente.")

    # 6. Probar comportamiento de backlog vacío
    print("\n[🔌 Paso 6]: Probando escenario de backlog vacío...")
    master.redis_client.set("scrum:backlog_empty", "true")
    # sim_worker_2 pollea su cola que ahora estará vacía tras ejecutar su tarea (limpiamos su cola para simular que terminó)
    master.redis_client.delete("scrum:queue:sim_worker_2")
    
    # Pollear para disparar el mensaje de "no hay tareas disponibles"
    # Dado que get_task() retorna None si no hay, validamos que la lógica imprima correctamente
    print("-> sim_worker_2 comprueba tareas:")
    task = worker2.get_task()
    if not task:
        backlog_empty = worker2.redis_client.get("scrum:backlog_empty") == "true"
        if backlog_empty:
            print("👷 [Worker sim_worker_2]: No hay tareas disponibles en el backlog.")

    print("\n==================================================")
    print("🧪 SIMULACIÓN FINALIZADA CON ÉXITO")
    print("==================================================")

    # Limpiar
    master.shutdown()
    worker1.shutdown()
    worker2.shutdown()

if __name__ == "__main__":
    run_simulation()
