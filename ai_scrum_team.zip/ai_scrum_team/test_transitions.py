import os
from dotenv import load_dotenv
load_dotenv(dotenv_path=r"c:\apps\cloudfly\ai_scrum_team\.env")

from tools import jira_wrapper

if not jira_wrapper:
    print("Jira wrapper not loaded.")
    exit(1)

try:
    transitions = jira_wrapper.jira.get_issue_transitions("CLOUD-41")
    print("Available Transitions:")
    for t in transitions:
        print(f"- ID: {t.get('id')}, Name: {t.get('name')}, To Status: {t.get('to', {}).get('name')}")
except Exception as e:
    print("Error:", e)
