import pytest
from fastapi.testclient import TestClient
from ai_scrum_team.main import app
import os

client = TestClient(app)

@pytest.fixture(autouse=True)
def set_auth_token(monkeypatch):
    monkeypatch.setenv("HANDOFF_AUTH_TOKEN", "testtoken")
    monkeypatch.setenv("AI_AGENT_URL", "http://example.com/handoff")

def test_handoff_missing_auth():
    response = client.post("/ia_scrum_team/handoff", json={"ticket_id": "123", "user_id": "u1", "context": {}})
    assert response.status_code == 401
    assert response.json()["detail"] == "Unauthorized handoff request"

def test_handoff_invalid_payload():
    response = client.post(
        "/ia_scrum_team/handoff",
        headers={"X-Auth-Token": "testtoken"},
        json={"ticket_id": "123"},  # missing required fields
    )
    assert response.status_code == 422

def test_handoff_success(monkeypatch, requests_mock):
    # Mock downstream AI agent response
    requests_mock.post("http://example.com/handoff", json={"result": "ok"}, status_code=200)
    response = client.post(
        "/ia_scrum_team/handoff",
        headers={"X-Auth-Token": "testtoken"},
        json={"ticket_id": "123", "user_id": "u1", "context": {"foo": "bar"}, "priority": 1},
    )
    assert response.status_code == 202
    assert response.json()["status"] == "queued"
    assert response.json()["ticket_id"] == "123"
