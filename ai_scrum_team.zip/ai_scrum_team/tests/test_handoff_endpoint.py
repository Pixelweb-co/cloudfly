# test_handoff_endpoint.py
"""Tests for the handoff endpoint in ai_scrum_team."""

from fastapi.testclient import TestClient
from ai_scrum_team.main import app

client = TestClient(app)

def test_handoff_high_priority():
    payload = {
        "ticket_id": "T123",
        "priority": "high",
        "language": "en",
        "product": "support"
    }
    response = client.post("/ia_scrum_team/handoff", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["agent"] == "senior_agent"
    assert "high priority" in data["reason"]

def test_handoff_spanish():
    payload = {
        "ticket_id": "T124",
        "priority": "low",
        "language": "es",
        "product": "support"
    }
    response = client.post("/ia_scrum_team/handoff", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["agent"] == "spanish_agent"

def test_handoff_billing():
    payload = {
        "ticket_id": "T125",
        "priority": "low",
        "language": "en",
        "product": "billing"
    }
    response = client.post("/ia_scrum_team/handoff", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["agent"] == "billing_agent"

def test_handoff_default():
    payload = {
        "ticket_id": "T126",
        "priority": "low",
        "language": "en",
        "product": "other"
    }
    response = client.post("/ia_scrum_team/handoff", json=payload)
    assert response.status_code == 200
    data = response.json()
    assert data["agent"] == "general_agent"
