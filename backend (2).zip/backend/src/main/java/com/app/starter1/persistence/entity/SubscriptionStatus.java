package com.app.starter1.persistence.entity;

public enum SubscriptionStatus {
    ACTIVE,
    CANCELLED,
    EXPIRED,
    SUSPENDED,
    PENDING
}
