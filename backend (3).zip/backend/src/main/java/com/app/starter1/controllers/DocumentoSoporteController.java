package com.app.starter1.controllers;

import com.app.starter1.dto.*;
import com.app.starter1.services.DocumentoSoporteService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/**
 * Controller REST para Documentos Soporte DIAN
 */
@RestController
@RequestMapping("/api/v1/documentos-soporte")
@RequiredArgsConstructor
@Slf4j
@CrossOrigin(origins = "*")
public class DocumentoSoporteController {

    private final DocumentoSoporteService service;

    /**
     * POST /api/v1/documentos-soporte
     * Crear nuevo documento soporte
     */
    @PostMapping
    public ResponseEntity<DocumentoSoporteResponse> crear(
            @Valid @RequestBody DocumentoSoporteRequest request,
            @RequestParam Long tenantId,
            Authentication authentication) {
        log.info("POST /documentos-soporte - Tenant: {}", tenantId);

        String username = authentication != null ? authentication.getName() : "system";
        DocumentoSoporteResponse response = service.crear(request, tenantId, username);

        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    /**
     * GET /api/v1/documentos-soporte
     * Listar documentos soporte del tenant
     */
    @GetMapping
    public ResponseEntity<List<DocumentoSoporteResponse>> listar(
            @RequestParam Long tenantId) {
        log.info("GET /documentos-soporte - Tenant: {}", tenantId);

        List<DocumentoSoporteResponse> documentos = service.listar(tenantId);
        return ResponseEntity.ok(documentos);
    }

    /**
     * GET /api/v1/documentos-soporte/{id}
     * Obtener documento soporte por ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<DocumentoSoporteResponse> buscarPorId(@PathVariable Long id) {
        log.info("GET /documentos-soporte/{}", id);

        DocumentoSoporteResponse doc = service.buscarPorId(id);
        return ResponseEntity.ok(doc);
    }

    /**
     * GET /api/v1/documentos-soporte/proveedor/{proveedorId}
     * Obtener documentos de un proveedor
     */
    @GetMapping("/proveedor/{proveedorId}")
    public ResponseEntity<List<DocumentoSoporteResponse>> buscarPorProveedor(
            @PathVariable Long proveedorId) {
        log.info("GET /documentos-soporte/proveedor/{}", proveedorId);

        List<DocumentoSoporteResponse> documentos = service.buscarPorProveedor(proveedorId);
        return ResponseEntity.ok(documentos);
    }

    /**
     * GET /api/v1/documentos-soporte/rango-fechas
     * Buscar documentos por rango de fechas
     */
    @GetMapping("/rango-fechas")
    public ResponseEntity<List<DocumentoSoporteResponse>> buscarPorFechas(
            @RequestParam Long tenantId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaInicio,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate fechaFin) {
        log.info("GET /documentos-soporte/rango-fechas - {} a {}", fechaInicio, fechaFin);

        List<DocumentoSoporteResponse> documentos = service.buscarPorFechas(tenantId, fechaInicio, fechaFin);
        return ResponseEntity.ok(documentos);
    }

    /**
     * PUT /api/v1/documentos-soporte/{id}
     * Actualizar documento soporte
     */
    @PutMapping("/{id}")
    public ResponseEntity<DocumentoSoporteResponse> actualizar(
            @PathVariable Long id,
            @Valid @RequestBody DocumentoSoporteRequest request) {
        log.info("PUT /documentos-soporte/{}", id);

        DocumentoSoporteResponse doc = service.actualizar(id, request);
        return ResponseEntity.ok(doc);
    }

    /**
     * POST /api/v1/documentos-soporte/{id}/aprobar
     * Aprobar documento soporte (genera contabilidad)
     */
    @PostMapping("/{id}/aprobar")
    public ResponseEntity<DocumentoSoporteResponse> aprobar(
            @PathVariable Long id,
            Authentication authentication) {
        log.info("POST /documentos-soporte/{}/aprobar", id);

        String username = authentication != null ? authentication.getName() : "system";
        DocumentoSoporteResponse doc = service.aprobar(id, username);

        return ResponseEntity.ok(doc);
    }

    /**
     * POST /api/v1/documentos-soporte/{id}/enviar-dian
     * Enviar documento soporte a DIAN
     */
    @PostMapping("/{id}/enviar-dian")
    public ResponseEntity<DocumentoSoporteResponse> enviarDian(@PathVariable Long id) {
        log.info("POST /documentos-soporte/{}/enviar-dian", id);

        DocumentoSoporteResponse doc = service.enviarDian(id);
        return ResponseEntity.ok(doc);
    }

    /**
     * DELETE /api/v1/documentos-soporte/{id}
     * Eliminar documento soporte
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        log.info("DELETE /documentos-soporte/{}", id);

        service.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}
