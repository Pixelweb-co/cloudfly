package com.app.starter1.dto;

import jakarta.validation.constraints.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentoSoporteRequest {

    private Long proveedorId; // Opcional si se selecciona de maestro

    // Datos del proveedor (obligatorios)
    @NotBlank(message = "El tipo de documento del proveedor es obligatorio")
    @Size(max = 2)
    private String proveedorTipoDocumento;

    @NotBlank(message = "El número de documento del proveedor es obligatorio")
    @Size(max = 20)
    private String proveedorNumeroDocumento;

    @Size(max = 1)
    private String proveedorDV;

    @NotBlank(message = "La razón social del proveedor es obligatoria")
    @Size(max = 450)
    private String proveedorRazonSocial;

    @Size(max = 500)
    private String proveedorDireccion;

    @Size(max = 5)
    private String codigoDaneCiudadProveedor;

    @Size(max = 100)
    private String proveedorCiudad;

    @Size(max = 2)
    private String codigoDaneDepartamentoProveedor;

    @Size(max = 100)
    private String proveedorDepartamento;

    @Size(max = 2)
    private String proveedorPais;

    @Size(max = 50)
    private String proveedorTelefono;

    @Email
    @Size(max = 255)
    private String proveedorEmail;

    // Datos del documento
    @NotNull(message = "La fecha es obligatoria")
    private LocalDate fecha;

    @Size(max = 500)
    private String cufeProveedor;

    @Size(max = 50)
    private String numeroFacturaProveedor;

    // Items
    @NotNull(message = "Debe incluir al menos un item")
    @Size(min = 1)
    private List<DocumentoSoporteItemDTO> items;

    private String observaciones;
    private String ambienteDian;
}
