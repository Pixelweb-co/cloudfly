package com.app.starter1.dto;

import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentoSoporteResponse {

    private Long id;
    private Long tenantId;
    private String numeroDocumento;
    private String prefijoDian;
    private Long consecutivoDian;
    private String cuds;
    private LocalDate fecha;
    private java.time.LocalTime horaEmision;

    // Proveedor
    private Long proveedorId;
    private String proveedorTipoDocumento;
    private String proveedorNumeroDocumento;
    private String proveedorDV;
    private String proveedorNitCompleto;
    private String proveedorRazonSocial;
    private String proveedorDireccion;
    private String codigoDaneCiudadProveedor;
    private String proveedorCiudad;
    private String codigoDaneDepartamentoProveedor;
    private String proveedorDepartamento;
    private String proveedorPais;
    private String proveedorTelefono;
    private String proveedorEmail;
    private String cufeProveedor;
    private String numeroFacturaProveedor;

    // Items
    private List<DocumentoSoporteItemDTO> items;

    // Totales
    private BigDecimal subtotal;
    private BigDecimal totalDescuentos;
    private BigDecimal totalCargos;
    private BigDecimal baseGravable;
    private BigDecimal totalIva;
    private BigDecimal totalImpuestos;
    private BigDecimal total;

    // Estado
    private String estado;
    private String ambienteDian;
    private String mensajeDian;
    private String observaciones;

    // Contabilidad
    private Boolean contabilidadGenerada;
    private Long asientoContableId;

    // Auditoría
    private LocalDateTime createdAt;
    private LocalDateTime updatedAt;
    private String createdBy;
    private String approvedBy;
    private LocalDateTime approvedAt;
}
