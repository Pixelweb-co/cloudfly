package com.app.starter1.mapper;

import com.app.starter1.dto.*;
import com.app.starter1.persistence.entity.*;
import com.app.starter1.persistence.repository.ProveedorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.stream.Collectors;

@Component
@RequiredArgsConstructor
public class DocumentoSoporteMapper {

    private final ProveedorRepository proveedorRepository;

    public DocumentoSoporte toEntity(DocumentoSoporteRequest request, Long tenantId) {
        DocumentoSoporte doc = DocumentoSoporte.builder()
                .tenantId(tenantId)
                .fecha(request.getFecha())
                .horaEmision(java.time.LocalTime.now())
                // Datos proveedor
                .proveedorTipoDocumento(request.getProveedorTipoDocumento())
                .proveedorNumeroDocumento(request.getProveedorNumeroDocumento())
                .proveedorDV(request.getProveedorDV())
                .proveedorRazonSocial(request.getProveedorRazonSocial())
                .proveedorDireccion(request.getProveedorDireccion())
                .codigoDaneCiudadProveedor(request.getCodigoDaneCiudadProveedor())
                .proveedorCiudad(request.getProveedorCiudad())
                .codigoDaneDepartamentoProveedor(request.getCodigoDaneDepartamentoProveedor())
                .proveedorDepartamento(request.getProveedorDepartamento())
                .proveedorPais(request.getProveedorPais() != null ? request.getProveedorPais() : "CO")
                .proveedorTelefono(request.getProveedorTelefono())
                .proveedorEmail(request.getProveedorEmail())
                .cufeProveedor(request.getCufeProveedor())
                .numeroFacturaProveedor(request.getNumeroFacturaProveedor())
                .observaciones(request.getObservaciones())
                .ambienteDian(request.getAmbienteDian() != null ? request.getAmbienteDian() : "2")
                .estado(DocumentoSoporte.EstadoDocumentoSoporte.BORRADOR)
                .build();

        // Si se envió proveedorId, cargar y asociar
        if (request.getProveedorId() != null) {
            proveedorRepository.findById(request.getProveedorId())
                    .ifPresent(doc::setProveedor);
        }

        // Convertir items
        if (request.getItems() != null) {
            request.getItems().forEach(itemDTO -> {
                DocumentoSoporteItem item = toItemEntity(itemDTO);
                doc.addItem(item);
            });
        }

        // Calcular totales
        doc.calcularTotales();

        return doc;
    }

    public DocumentoSoporteItem toItemEntity(DocumentoSoporteItemDTO dto) {
        DocumentoSoporteItem item = DocumentoSoporteItem.builder()
                .numeroLinea(dto.getNumeroLinea())
                .productId(dto.getProductId())
                .productName(dto.getProductName())
                .codigoProducto(dto.getCodigoProducto())
                .descripcion(dto.getDescripcion())
                .quantity(dto.getQuantity())
                .unitPrice(dto.getUnitPrice())
                .subtotal(dto.getSubtotal())
                .unidadMedidaUNECE(dto.getUnidadMedidaUNECE())
                .marca(dto.getMarca())
                .modelo(dto.getModelo())
                .tipoImpuesto(dto.getTipoImpuesto())
                .tarifaIVA(dto.getTarifaIVA())
                .porcentajeImpuesto(dto.getPorcentajeImpuesto())
                .baseImpuesto(dto.getBaseImpuesto())
                .impuestoCalculado(dto.getImpuestoCalculado())
                .valorDescuentos(dto.getValorDescuentos())
                .valorCargos(dto.getValorCargos())
                .total(dto.getTotal())
                .build();

        // Calcular si no vienen valores
        if (item.getSubtotal() == null || item.getTotal() == null) {
            item.calcularTotales();
        }

        return item;
    }

    public DocumentoSoporteResponse toResponse(DocumentoSoporte entity) {
        if (entity == null) {
            return null;
        }

        return DocumentoSoporteResponse.builder()
                .id(entity.getId())
                .tenantId(entity.getTenantId())
                .numeroDocumento(entity.getNumeroDocumento())
                .prefijoDian(entity.getPrefijoDian())
                .consecutivoDian(entity.getConsecutivoDian())
                .cuds(entity.getCuds())
                .fecha(entity.getFecha())
                .horaEmision(entity.getHoraEmision())
                // Proveedor
                .proveedorId(entity.getProveedor() != null ? entity.getProveedor().getId() : null)
                .proveedorTipoDocumento(entity.getProveedorTipoDocumento())
                .proveedorNumeroDocumento(entity.getProveedorNumeroDocumento())
                .proveedorDV(entity.getProveedorDV())
                .proveedorNitCompleto(entity.getProveedorNitCompleto())
                .proveedorRazonSocial(entity.getProveedorRazonSocial())
                .proveedorDireccion(entity.getProveedorDireccion())
                .codigoDaneCiudadProveedor(entity.getCodigoDaneCiudadProveedor())
                .proveedorCiudad(entity.getProveedorCiudad())
                .codigoDaneDepartamentoProveedor(entity.getCodigoDaneDepartamentoProveedor())
                .proveedorDepartamento(entity.getProveedorDepartamento())
                .proveedorPais(entity.getProveedorPais())
                .proveedorTelefono(entity.getProveedorTelefono())
                .proveedorEmail(entity.getProveedorEmail())
                .cufeProveedor(entity.getCufeProveedor())
                .numeroFacturaProveedor(entity.getNumeroFacturaProveedor())
                // Items
                .items(entity.getItems().stream()
                        .map(this::toItemDTO)
                        .collect(Collectors.toList()))
                // Totales
                .subtotal(entity.getSubtotal())
                .totalDescuentos(entity.getTotalDescuentos())
                .totalCargos(entity.getTotalCargos())
                .baseGravable(entity.getBaseGravable())
                .totalIva(entity.getTotalIva())
                .totalImpuestos(entity.getTotalImpuestos())
                .total(entity.getTotal())
                // Estado
                .estado(entity.getEstado() != null ? entity.getEstado().name() : null)
                .ambienteDian(entity.getAmbienteDian())
                .mensajeDian(entity.getMensajeDian())
                .observaciones(entity.getObservaciones())
                // Contabilidad
                .contabilidadGenerada(entity.getContabilidadGenerada())
                .asientoContableId(entity.getAsientoContableId())
                // Auditoría
                .createdAt(entity.getCreatedAt())
                .updatedAt(entity.getUpdatedAt())
                .createdBy(entity.getCreatedBy())
                .approvedBy(entity.getApprovedBy())
                .approvedAt(entity.getApprovedAt())
                .build();
    }

    public DocumentoSoporteItemDTO toItemDTO(DocumentoSoporteItem entity) {
        return DocumentoSoporteItemDTO.builder()
                .id(entity.getId())
                .numeroLinea(entity.getNumeroLinea())
                .productId(entity.getProductId())
                .productName(entity.getProductName())
                .codigoProducto(entity.getCodigoProducto())
                .descripcion(entity.getDescripcion())
                .quantity(entity.getQuantity())
                .unitPrice(entity.getUnitPrice())
                .subtotal(entity.getSubtotal())
                .unidadMedidaUNECE(entity.getUnidadMedidaUNECE())
                .marca(entity.getMarca())
                .modelo(entity.getModelo())
                .tipoImpuesto(entity.getTipoImpuesto())
                .tarifaIVA(entity.getTarifaIVA())
                .porcentajeImpuesto(entity.getPorcentajeImpuesto())
                .baseImpuesto(entity.getBaseImpuesto())
                .impuestoCalculado(entity.getImpuestoCalculado())
                .valorDescuentos(entity.getValorDescuentos())
                .valorCargos(entity.getValorCargos())
                .total(entity.getTotal())
                .build();
    }
}
