package com.app.starter1.persistence.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Entidad DocumentoSoporte - Documento Soporte de Adquisiciones DIAN UBL 2.1
 * Usado cuando el proveedor no está obligado a facturar electrónicamente
 */
@Entity
@Table(name = "documentos_soporte", indexes = {
        @Index(name = "idx_ds_tenant", columnList = "tenant_id"),
        @Index(name = "idx_ds_numero", columnList = "numero_documento"),
        @Index(name = "idx_ds_proveedor", columnList = "proveedor_numero_documento"),
        @Index(name = "idx_ds_estado", columnList = "estado"),
        @Index(name = "idx_ds_cuds", columnList = "cuds")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentoSoporte {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    // ========== MULTI-TENANCY ==========

    @Column(name = "tenant_id", nullable = false)
    private Long tenantId;

    // ========== IDENTIFICACIÓN DEL DOCUMENTO ==========

    /**
     * Número interno del documento soporte
     */
    @Column(name = "numero_documento", unique = true, length = 50, nullable = false)
    private String numeroDocumento;

    /**
     * Prefijo DIAN para documentos soporte (ej: DS)
     */
    @Column(name = "prefijo_dian", length = 10)
    private String prefijoDian;

    /**
     * Número consecutivo DIAN
     */
    @Column(name = "consecutivo_dian")
    private Long consecutivoDian;

    /**
     * CUDS (Código Único de Documento Soporte) - generado al firmar
     */
    @Column(name = "cuds", length = 500)
    private String cuds;

    /**
     * Fecha de emisión del documento soporte
     */
    @Column(name = "fecha", nullable = false)
    private LocalDate fecha;

    /**
     * Hora de emisión
     */
    @Column(name = "hora_emision")
    private java.time.LocalTime horaEmision;

    // ========== RELACIÓN CON PROVEEDOR ==========

    /**
     * Proveedor asociado (relación con maestro de proveedores)
     */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "proveedor_id")
    private Proveedor proveedor;

    // ========== INFORMACIÓN DEL PROVEEDOR - SNAPSHOT HISTÓRICO (OBLIGATORIO)
    // ==========
    // Estos campos se duplican como snapshot para mantener datos históricos
    // incluso si el proveedor se modifica o elimina posteriormente

    /**
     * Tipo de documento del proveedor: 13=CC, 22=CE, 31=NIT, 41=Pasaporte
     */
    @Column(name = "proveedor_tipo_documento", nullable = false, length = 2)
    private String proveedorTipoDocumento;

    /**
     * Número de identificación del proveedor (sin DV)
     */
    @Column(name = "proveedor_numero_documento", nullable = false, length = 20)
    private String proveedorNumeroDocumento;

    /**
     * Dígito de verificación (solo para NIT)
     */
    @Column(name = "proveedor_dv", length = 1)
    private String proveedorDV;

    /**
     * Razón social o nombre completo del proveedor
     */
    @Column(name = "proveedor_razon_social", nullable = false, length = 450)
    private String proveedorRazonSocial;

    /**
     * Dirección del proveedor
     */
    @Column(name = "proveedor_direccion", length = 500)
    private String proveedorDireccion;

    /**
     * Código DANE de la ciudad del proveedor
     */
    @Column(name = "codigo_dane_ciudad_proveedor", length = 5)
    private String codigoDaneCiudadProveedor;

    /**
     * Ciudad del proveedor
     */
    @Column(name = "proveedor_ciudad", length = 100)
    private String proveedorCiudad;

    /**
     * Código DANE del departamento del proveedor
     */
    @Column(name = "codigo_dane_departamento_proveedor", length = 2)
    private String codigoDaneDepartamentoProveedor;

    /**
     * Departamento del proveedor
     */
    @Column(name = "proveedor_departamento", length = 100)
    private String proveedorDepartamento;

    /**
     * País del proveedor (generalmente CO)
     */
    @Column(name = "proveedor_pais", length = 2)
    @Builder.Default
    private String proveedorPais = "CO";

    /**
     * Teléfono del proveedor
     */
    @Column(name = "proveedor_telefono", length = 50)
    private String proveedorTelefono;

    /**
     * Email del proveedor
     */
    @Column(name = "proveedor_email", length = 255)
    private String proveedorEmail;

    /**
     * CUFE del proveedor (si el proveedor emitió factura electrónica)
     */
    @Column(name = "cufe_proveedor", length = 500)
    private String cufeProveedor;

    /**
     * Número de factura del proveedor (si existe)
     */
    @Column(name = "numero_factura_proveedor", length = 50)
    private String numeroFacturaProveedor;

    // ========== DETALLES/ITEMS ==========

    /**
     * Ítems del documento soporte
     */
    @OneToMany(mappedBy = "documentoSoporte", cascade = CascadeType.ALL, orphanRemoval = true)
    @Builder.Default
    private List<DocumentoSoporteItem> items = new ArrayList<>();

    // ========== TOTALES ==========

    /**
     * Subtotal (suma de líneas sin impuestos)
     */
    @Column(name = "subtotal", precision = 15, scale = 2, nullable = false)
    private BigDecimal subtotal;

    /**
     * Total descuentos
     */
    @Column(name = "total_descuentos", precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal totalDescuentos = BigDecimal.ZERO;

    /**
     * Total cargos
     */
    @Column(name = "total_cargos", precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal totalCargos = BigDecimal.ZERO;

    /**
     * Base gravable (subtotal - descuentos + cargos)
     */
    @Column(name = "base_gravable", precision = 15, scale = 2)
    private BigDecimal baseGravable;

    /**
     * Total IVA
     */
    @Column(name = "total_iva", precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal totalIva = BigDecimal.ZERO;

    /**
     * Total impuestos (IVA + otros)
     */
    @Column(name = "total_impuestos", precision = 15, scale = 2)
    @Builder.Default
    private BigDecimal totalImpuestos = BigDecimal.ZERO;

    /**
     * Total del documento
     */
    @Column(name = "total", precision = 15, scale = 2, nullable = false)
    private BigDecimal total;

    // ========== ESTADO Y CONTROL ==========

    /**
     * Estado del documento soporte
     */
    @Enumerated(EnumType.STRING)
    @Column(name = "estado", length = 20, nullable = false)
    @Builder.Default
    private EstadoDocumentoSoporte estado = EstadoDocumentoSoporte.BORRADOR;

    /**
     * Ambiente DIAN (1=Producción, 2=Pruebas)
     */
    @Column(name = "ambiente_dian", length = 1)
    @Builder.Default
    private String ambienteDian = "2";

    /**
     * XML firmado del documento
     */
    @Lob
    @Column(name = "xml_firmado", columnDefinition = "LONGBLOB")
    private byte[] xmlFirmado;

    /**
     * XML de respuesta DIAN
     */
    @Lob
    @Column(name = "xml_respuesta_dian", columnDefinition = "LONGBLOB")
    private byte[] xmlRespuestaDian;

    /**
     * Mensaje de respuesta DIAN
     */
    @Column(name = "mensaje_dian", columnDefinition = "TEXT")
    private String mensajeDian;

    /**
     * Observaciones generales
     */
    @Column(name = "observaciones", columnDefinition = "TEXT")
    private String observaciones;

    /**
     * Indica si ya se generaron movimientos contables
     */
    @Column(name = "contabilidad_generada")
    @Builder.Default
    private Boolean contabilidadGenerada = false;

    /**
     * ID del asiento contable generado
     */
    @Column(name = "asiento_contable_id")
    private Long asientoContableId;

    // ========== AUDITORÍA ==========

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    @Column(name = "created_by", length = 100)
    private String createdBy;

    @Column(name = "approved_by", length = 100)
    private String approvedBy;

    @Column(name = "approved_at")
    private LocalDateTime approvedAt;

    // ========== MÉTODOS AUXILIARES ==========

    /**
     * Calcula los totales del documento
     */
    public void calcularTotales() {
        this.subtotal = items.stream()
                .map(item -> item.getSubtotal() != null ? item.getSubtotal() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        this.totalDescuentos = items.stream()
                .map(item -> item.getValorDescuentos() != null ? item.getValorDescuentos() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        this.totalCargos = items.stream()
                .map(item -> item.getValorCargos() != null ? item.getValorCargos() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        this.baseGravable = subtotal.subtract(totalDescuentos).add(totalCargos);

        this.totalIva = items.stream()
                .map(item -> {
                    if (item.getTipoImpuesto() != null && item.getTipoImpuesto().equals("IVA")) {
                        return item.getImpuestoCalculado() != null ? item.getImpuestoCalculado() : BigDecimal.ZERO;
                    }
                    return BigDecimal.ZERO;
                })
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        this.totalImpuestos = items.stream()
                .map(item -> item.getImpuestoCalculado() != null ? item.getImpuestoCalculado() : BigDecimal.ZERO)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        this.total = baseGravable.add(totalImpuestos);
    }

    /**
     * Agrega un item al documento
     */
    public void addItem(DocumentoSoporteItem item) {
        items.add(item);
        item.setDocumentoSoporte(this);
    }

    /**
     * Obtiene NIT completo del proveedor con DV
     */
    public String getProveedorNitCompleto() {
        if (proveedorDV != null && !proveedorDV.isEmpty()) {
            return proveedorNumeroDocumento + "-" + proveedorDV;
        }
        return proveedorNumeroDocumento;
    }

    /**
     * Enum de estados
     */
    public enum EstadoDocumentoSoporte {
        BORRADOR, // En construcción
        APROBADO, // Aprobado internamente
        ENVIADO, // Enviado a DIAN
        ACEPTADO, // Aceptado por DIAN
        RECHAZADO // Rechazado por DIAN
    }
}
