package com.app.starter1.persistence.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

/**
 * Item de Documento Soporte - similar a InvoiceItem pero para compras
 */
@Entity
@Table(name = "documento_soporte_items")
@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class DocumentoSoporteItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "documento_soporte_id", nullable = false)
    @JsonIgnore
    @ToString.Exclude
    private DocumentoSoporte documentoSoporte;

    @Column(name = "numero_linea")
    private Integer numeroLinea;

    // Si la compra es de un producto existente en inventario
    @Column(name = "product_id")
    private Long productId;

    @Column(nullable = false, length = 500)
    private String productName;

    @Column(name = "codigo_producto", length = 100)
    private String codigoProducto;

    @Column(columnDefinition = "TEXT")
    private String descripcion;

    @Column(nullable = false)
    private Integer quantity;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal unitPrice;

    @Column(precision = 12, scale = 2)
    private BigDecimal subtotal;

    // Campos DIAN
    @Column(name = "unidad_medida_unece", length = 10)
    private String unidadMedidaUNECE;

    @Column(name = "marca", length = 200)
    private String marca;

    @Column(name = "modelo", length = 200)
    private String modelo;

    @Column(name = "tipo_impuesto", length = 20)
    private String tipoImpuesto;

    @Column(name = "tarifa_iva", length = 20)
    private String tarifaIVA;

    @Column(name = "porcentaje_impuesto", precision = 52)
    private BigDecimal porcentajeImpuesto;

    @Column(name = "base_impuesto", precision = 12, scale = 2)
    private BigDecimal baseImpuesto;

    @Column(name = "impuesto_calculado", precision = 12, scale = 2)
    private BigDecimal impuestoCalculado;

    @Column(name = "valor_descuentos", precision = 12, scale = 2)
    @Builder.Default
    private BigDecimal valorDescuentos = BigDecimal.ZERO;

    @Column(name = "valor_cargos", precision = 12, scale = 2)
    @Builder.Default
    private BigDecimal valorCargos = BigDecimal.ZERO;

    @Column(nullable = false, precision = 12, scale = 2)
    private BigDecimal total;

    // Métodos auxiliares
    public void calcularTotales() {
        if (quantity != null && unitPrice != null) {
            this.subtotal = unitPrice.multiply(BigDecimal.valueOf(quantity));
        }

        BigDecimal base = subtotal != null ? subtotal : BigDecimal.ZERO;
        base = base.subtract(valorDescuentos != null ? valorDescuentos : BigDecimal.ZERO);
        base = base.add(valorCargos != null ? valorCargos : BigDecimal.ZERO);
        this.baseImpuesto = base;

        if (porcentajeImpuesto != null && baseImpuesto != null) {
            this.impuestoCalculado = baseImpuesto.multiply(porcentajeImpuesto)
                    .divide(BigDecimal.valueOf(100), 2, BigDecimal.ROUND_HALF_UP);
        }

        this.total = baseImpuesto.add(impuestoCalculado != null ? impuestoCalculado : BigDecimal.ZERO);
    }
}
