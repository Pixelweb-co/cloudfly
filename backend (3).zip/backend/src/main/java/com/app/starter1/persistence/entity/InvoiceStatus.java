package com.app.starter1.persistence.entity;

public enum InvoiceStatus {
    DRAFT, // Borrador
    ISSUED, // Emitida
    PAID, // Pagada
    CANCELLED // Anulada
}
