package com.app.starter1.persistence.entity;

public enum MessagePlatform {
    WHATSAPP,
    FACEBOOK_MESSENGER,
    INSTAGRAM_DM,
    TELEGRAM,
    WEBCHAT,
    EMAIL,
    SMS
}
