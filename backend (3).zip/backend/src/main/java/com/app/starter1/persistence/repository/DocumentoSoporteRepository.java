package com.app.starter1.persistence.repository;

import com.app.starter1.persistence.entity.DocumentoSoporte;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

@Repository
public interface DocumentoSoporteRepository extends JpaRepository<DocumentoSoporte, Long> {

    List<DocumentoSoporte> findByTenantIdAndEstado(Long tenantId, DocumentoSoporte.EstadoDocumentoSoporte estado);

    List<DocumentoSoporte> findByTenantIdOrderByFechaDesc(Long tenantId);

    List<DocumentoSoporte> findByProveedorId(Long proveedorId);

    Optional<DocumentoSoporte> findByNumeroDocumento(String numeroDocumento);

    Optional<DocumentoSoporte> findByCuds(String cuds);

    List<DocumentoSoporte> findByTenantIdAndFechaBetween(Long tenantId, LocalDate fechaInicio, LocalDate fechaFin);

    boolean existsByNumeroDocumento(String numeroDocumento);

    long countByTenantIdAndEstado(Long tenantId, DocumentoSoporte.EstadoDocumentoSoporte estado);
}
