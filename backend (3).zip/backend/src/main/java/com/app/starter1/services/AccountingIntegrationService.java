package com.app.starter1.services;

import com.app.starter1.dto.accounting.VoucherEntryDTO;
import com.app.starter1.dto.accounting.VoucherRequestDTO;
import com.app.starter1.persistence.entity.*;
import com.app.starter1.persistence.repository.ChartOfAccountRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Servicio de Integración Automática Contable
 * Genera comprobantes a partir de documentos de negocio (Facturas, Nómina,
 * etc.)
 */
@Service
@RequiredArgsConstructor
@Slf4j
public class AccountingIntegrationService {

    private final AccountingVoucherService voucherService;
    private final ChartOfAccountRepository accountRepository;

    // --- INTEGRACIÓN NÓMINA ---

    @Transactional
    public void generatePayrollLiquidationVoucher(PayrollPeriod period, List<PayrollReceipt> receipts) {
        log.info("Generando comprobante de nómina para periodo: {}", period.getId());

        VoucherRequestDTO voucherRequest = new VoucherRequestDTO();
        voucherRequest.setTenantId(1); // TODO: Dinámico
        voucherRequest.setVoucherType("EGRESO"); // O Causación
        voucherRequest.setDate(LocalDate.now());
        voucherRequest.setDescription("Causación Nómina " + period.getPeriodName());
        voucherRequest.setReference("NOM-" + period.getId());

        List<VoucherEntryDTO> entries = new ArrayList<>();

        // 1. Agrupar por Concepto (Simplificado)
        // En un sistema real, se agruparía por cuenta contable configurada en el
        // concepto
        // Aquí asumiremos cuentas estándar

        BigDecimal totalSalarios = BigDecimal.ZERO;
        BigDecimal totalSalud = BigDecimal.ZERO;
        BigDecimal totalPension = BigDecimal.ZERO;
        BigDecimal totalNeto = BigDecimal.ZERO;

        for (PayrollReceipt r : receipts) {
            totalSalarios = totalSalarios.add(r.getTotalPerceptions());
            totalSalud = totalSalud.add(r.getHealthDeduction());
            totalPension = totalPension.add(r.getPensionDeduction());
            totalNeto = totalNeto.add(r.getNetPay());
        }

        // DEBITO: Gasto Sueldos (510506)
        entries.add(createEntry("510506", "Sueldos", totalSalarios, BigDecimal.ZERO));

        // CREDITO: Aportes Salud (237005)
        if (totalSalud.compareTo(BigDecimal.ZERO) > 0)
            entries.add(createEntry("237005", "Aportes Salud", BigDecimal.ZERO, totalSalud));

        // CREDITO: Aportes Pensión (238030)
        if (totalPension.compareTo(BigDecimal.ZERO) > 0)
            entries.add(createEntry("238030", "Aportes Pensión", BigDecimal.ZERO, totalPension));

        // CREDITO: Salarios por Pagar (2505) - Neto
        entries.add(createEntry("250501", "Salarios por Pagar", BigDecimal.ZERO, totalNeto));

        voucherRequest.setEntries(entries);

        // Crear Comprobante
        try {
            voucherService.createVoucher(voucherRequest);
            log.info("Comprobante de nómina creado exitosamente");
        } catch (Exception e) {
            log.error("Error creando comprobante de nómina: {}", e.getMessage());
            // No lanzamos excepción para no bloquear el proceso de nómina principal,
            // pero se debería notificar.
        }
    }

    // --- INTEGRACIÓN FACTURACIÓN ---

    @Transactional
    public void generateInvoiceVoucher(Invoice invoice) {
        log.info("Generando comprobante de venta para factura: {}", invoice.getInvoiceNumber());

        VoucherRequestDTO voucherRequest = new VoucherRequestDTO();
        voucherRequest.setTenantId(invoice.getTenantId().intValue());
        voucherRequest.setVoucherType("INGRESO");
        voucherRequest.setDate(invoice.getIssueDate().toLocalDate());
        voucherRequest.setDescription("Venta Factura " + invoice.getInvoiceNumber());
        voucherRequest.setReference(invoice.getInvoiceNumber());

        List<VoucherEntryDTO> entries = new ArrayList<>();

        // 1. DEBITO: Clientes (1305) - Total a Cobrar
        entries.add(createEntry("130505", "Clientes Nacionales", invoice.getTotal(), BigDecimal.ZERO));

        // 2. CREDITO: Ingresos (4135) - Subtotal
        entries.add(createEntry("413501", "Comercio al por mayor y menor", BigDecimal.ZERO, invoice.getSubtotal()));

        // 3. CREDITO: IVA Generado (2408)
        if (invoice.getTax() != null && invoice.getTax().compareTo(BigDecimal.ZERO) > 0) {
            entries.add(createEntry("240801", "IVA Generado", BigDecimal.ZERO, invoice.getTax()));
        }

        voucherRequest.setEntries(entries);

        voucherService.createVoucher(voucherRequest);
    }

    // --- INTEGRACIÓN DOCUMENTO SOPORTE (COMPRAS) ---

    @Transactional
    public void generateSupportDocumentVoucher(DocumentoSoporte doc) {
        log.info("Generando comprobante de compra para Documento Soporte: {}", doc.getNumeroDocumento());

        VoucherRequestDTO voucherRequest = new VoucherRequestDTO();
        voucherRequest.setTenantId(doc.getTenantId().intValue());
        voucherRequest.setVoucherType("EGRESO"); // O COMPRA
        voucherRequest.setDate(doc.getFecha());
        voucherRequest.setDescription(
                "Compra Doc. Soporte " + doc.getNumeroDocumento() + " - " + doc.getProveedorRazonSocial());
        voucherRequest.setReference(doc.getNumeroDocumento());

        List<VoucherEntryDTO> entries = new ArrayList<>();

        // 1. DEBITO: Gasto o Inventario (51XX o 14XX)
        // Por simplificación usamos una cuenta genérica de gastos diversos (5195)
        entries.add(createEntry("519595", "Gastos Diversos (Doc Soporte)", doc.getSubtotal(), BigDecimal.ZERO));

        // 2. DEBITO: IVA Descontable (2408)
        if (doc.getTotalIva() != null && doc.getTotalIva().compareTo(BigDecimal.ZERO) > 0) {
            entries.add(createEntry("240810", "IVA Descontable", doc.getTotalIva(), BigDecimal.ZERO));
        }

        /*
         * // CAMPOS NO EXISTEN EN ENTIDAD AÚN
         * // 3. CREDITO: Retención en la Fuente (2365)
         * if (doc.getTotalRetefuente() != null &&
         * doc.getTotalRetefuente().compareTo(BigDecimal.ZERO) > 0) {
         * entries.add(createEntry("236540", "Retención en la fuente (Compras)",
         * BigDecimal.ZERO,
         * doc.getTotalRetefuente()));
         * }
         * 
         * // 4. CREDITO: Retención de Industria y Comercio (2368)
         * if (doc.getTotalReteIca() != null &&
         * doc.getTotalReteIca().compareTo(BigDecimal.ZERO) > 0) {
         * entries.add(createEntry("236805", "ReteICA", BigDecimal.ZERO,
         * doc.getTotalReteIca()));
         * }
         */

        // 5. CREDITO: Cuentas por Pagar Proveedores (2205)
        entries.add(createEntry("220501", "Proveedores Nacionales", BigDecimal.ZERO, doc.getTotal()));

        voucherRequest.setEntries(entries);

        voucherService.createVoucher(voucherRequest);
    }

    private VoucherEntryDTO createEntry(String accountCode, String description, BigDecimal debit, BigDecimal credit) {
        return VoucherEntryDTO.builder()
                .accountCode(accountCode)
                .description(description)
                .debitAmount(debit)
                .creditAmount(credit)
                .build();
    }
}
