package com.app.starter1.services;

import com.app.starter1.dto.*;
import com.app.starter1.mapper.DocumentoSoporteMapper;
import com.app.starter1.persistence.entity.DocumentoSoporte;
import com.app.starter1.persistence.repository.DocumentoSoporteRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class DocumentoSoporteService {

    private final DocumentoSoporteRepository repository;
    private final DocumentoSoporteMapper mapper;
    private final AccountingIntegrationService accountingIntegrationService;

    /**
     * Crear documento soporte en estado BORRADOR
     */
    @Transactional
    public DocumentoSoporteResponse crear(DocumentoSoporteRequest request, Long tenantId, String username) {
        log.info("Creando documento soporte para tenant: {}", tenantId);

        // Generar número de documento
        String numeroDocumento = generarNumeroDocumento(tenantId);

        DocumentoSoporte doc = mapper.toEntity(request, tenantId);
        doc.setNumeroDocumento(numeroDocumento);
        doc.setCreatedBy(username);

        doc = repository.save(doc);

        log.info("Documento soporte creado: {}", doc.getNumeroDocumento());
        return mapper.toResponse(doc);
    }

    /**
     * Aprobar documento soporte y GENERAR CONTABILIDAD
     */
    @Transactional
    public DocumentoSoporteResponse aprobar(Long id, String username) {
        log.info("Aprobando documento soporte ID: {}", id);

        DocumentoSoporte doc = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Documento soporte no encontrado"));

        if (doc.getEstado() != DocumentoSoporte.EstadoDocumentoSoporte.BORRADOR) {
            throw new RuntimeException("Solo se pueden aprobar documentos en estado BORRADOR");
        }

        // Cambiar estado
        doc.setEstado(DocumentoSoporte.EstadoDocumentoSoporte.APROBADO);
        doc.setApprovedBy(username);
        doc.setApprovedAt(LocalDateTime.now());

        // GENERAR MOVIMIENTOS CONTABLES (Compra)
        if (!doc.getContabilidadGenerada()) {
            generarContabilidad(doc);
            doc.setContabilidadGenerada(true);
        }

        doc = repository.save(doc);

        log.info("Documento soporte aprobado: {}", doc.getNumeroDocumento());
        return mapper.toResponse(doc);
    }

    /**
     * Enviar documento soporte a DIAN
     */
    @Transactional
    public DocumentoSoporteResponse enviarDian(Long id) {
        log.info("Enviando documento soporte a DIAN ID: {}", id);

        DocumentoSoporte doc = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Documento soporte no encontrado"));

        if (doc.getEstado() != DocumentoSoporte.EstadoDocumentoSoporte.APROBADO) {
            throw new RuntimeException("Solo se pueden enviar documentos APROBADOS");
        }

        // TODO: Integrar con microservicio DIAN
        // 1. Generar XML UBL 2.1 Documento Soporte
        // 2. Firmar XML
        // 3. Enviar a DIAN
        // 4. Procesar respuesta

        doc.setEstado(DocumentoSoporte.EstadoDocumentoSoporte.ENVIADO);
        doc = repository.save(doc);

        log.info("Documento soporte enviado a DIAN: {}", doc.getNumeroDocumento());
        return mapper.toResponse(doc);
    }

    /**
     * Actualizar documento soporte (solo si está en BORRADOR)
     */
    @Transactional
    public DocumentoSoporteResponse actualizar(Long id, DocumentoSoporteRequest request) {
        log.info("Actualizando documento soporte ID: {}", id);

        DocumentoSoporte doc = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Documento soporte no encontrado"));

        if (doc.getEstado() != DocumentoSoporte.EstadoDocumentoSoporte.BORRADOR) {
            throw new RuntimeException("Solo se pueden actualizar documentos en BORRADOR");
        }

        // Limpiar items actuales
        doc.getItems().clear();

        // Actualizar datos
        doc.setFecha(request.getFecha());
        doc.setProveedorTipoDocumento(request.getProveedorTipoDocumento());
        doc.setProveedorNumeroDocumento(request.getProveedorNumeroDocumento());
        doc.setProveedorDV(request.getProveedorDV());
        doc.setProveedorRazonSocial(request.getProveedorRazonSocial());
        doc.setProveedorDireccion(request.getProveedorDireccion());
        doc.setCodigoDaneCiudadProveedor(request.getCodigoDaneCiudadProveedor());
        doc.setProveedorCiudad(request.getProveedorCiudad());
        doc.setCodigoDaneDepartamentoProveedor(request.getCodigoDaneDepartamentoProveedor());
        doc.setProveedorDepartamento(request.getProveedorDepartamento());
        doc.setProveedorPais(request.getProveedorPais());
        doc.setProveedorTelefono(request.getProveedorTelefono());
        doc.setProveedorEmail(request.getProveedorEmail());
        doc.setCufeProveedor(request.getCufeProveedor());
        doc.setNumeroFacturaProveedor(request.getNumeroFacturaProveedor());
        doc.setObservaciones(request.getObservaciones());

        // Agregar nuevos items
        if (request.getItems() != null) {
            request.getItems().forEach(itemDTO -> {
                doc.addItem(mapper.toItemEntity(itemDTO));
            });
        }

        // Recalcular totales
        doc.calcularTotales();

        doc = repository.save(doc);

        log.info("Documento soporte actualizado: {}", id);
        return mapper.toResponse(doc);
    }

    /**
     * Buscar documentos soporte por tenant
     */
    @Transactional(readOnly = true)
    public List<DocumentoSoporteResponse> listar(Long tenantId) {
        return repository.findByTenantIdOrderByFechaDesc(tenantId).stream()
                .map(mapper::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * Buscar por ID
     */
    @Transactional(readOnly = true)
    public DocumentoSoporteResponse buscarPorId(Long id) {
        DocumentoSoporte doc = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Documento soporte no encontrado"));
        return mapper.toResponse(doc);
    }

    /**
     * Buscar documentos de un proveedor
     */
    @Transactional(readOnly = true)
    public List<DocumentoSoporteResponse> buscarPorProveedor(Long proveedorId) {
        return repository.findByProveedorId(proveedorId).stream()
                .map(mapper::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * Buscar por rango de fechas
     */
    @Transactional(readOnly = true)
    public List<DocumentoSoporteResponse> buscarPorFechas(Long tenantId, LocalDate fechaInicio, LocalDate fechaFin) {
        return repository.findByTenantIdAndFechaBetween(tenantId, fechaInicio, fechaFin).stream()
                .map(mapper::toResponse)
                .collect(Collectors.toList());
    }

    /**
     * GENERA MOVIMIENTOS CONTABLES por la compra
     */
    private void generarContabilidad(DocumentoSoporte doc) {
        log.info("💰 Generando contabilidad para documento soporte: {}", doc.getNumeroDocumento());

        try {
            accountingIntegrationService.generateSupportDocumentVoucher(doc);

            // Si no lanza excepción, marcamos como generada
            doc.setContabilidadGenerada(true);

            // Asiento contable ID no disponible directamente (void),
            // pero podríamos actualizar el método para retornarlo si fuera necesario.
            log.info("✅ Contabilidad generada exitosamente para documento {}", doc.getNumeroDocumento());

        } catch (Exception e) {
            log.error("❌ Error generando contabilidad", e);
            throw new RuntimeException("Error en generación contable: " + e.getMessage());
        }
    }

    /**
     * Genera número único para el documento soporte
     */
    private String generarNumeroDocumento(Long tenantId) {
        long count = repository.countByTenantIdAndEstado(
                tenantId,
                DocumentoSoporte.EstadoDocumentoSoporte.BORRADOR);
        return String.format("DS-%d-%06d", tenantId, count + 1);
    }

    /**
     * Eliminar documento (solo si está en BORRADOR)
     */
    @Transactional
    public void eliminar(Long id) {
        log.info("Eliminando documento soporte ID: {}", id);

        DocumentoSoporte doc = repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Documento soporte no encontrado"));

        if (doc.getEstado() != DocumentoSoporte.EstadoDocumentoSoporte.BORRADOR) {
            throw new RuntimeException("Solo se pueden eliminar documentos en BORRADOR");
        }

        repository.delete(doc);
        log.info("Documento soporte eliminado: {}", id);
    }
}
