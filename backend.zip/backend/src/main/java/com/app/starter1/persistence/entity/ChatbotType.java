package com.app.starter1.persistence.entity;

public enum ChatbotType {
    SALES,
    SUPPORT,
    SCHEDULING
}
