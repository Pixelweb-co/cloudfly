package com.app.starter1.persistence.entity;

public enum ContactType {
    LEAD,
    POTENTIAL_CUSTOMER,
    CUSTOMER,
    SUPPLIER,
    OTHER
}
