package com.app.starter1.persistence.entity;

public enum MessageDirection {
    INBOUND, // Cliente → Sistema
    OUTBOUND // Sistema → Cliente
}
