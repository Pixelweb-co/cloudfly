package com.app.starter1.persistence.entity;

public enum MessageStatus {
    PENDING,
    SENT,
    DELIVERED,
    READ,
    FAILED,
    DELETED
}
