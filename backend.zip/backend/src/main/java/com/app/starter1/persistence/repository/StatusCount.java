package com.app.starter1.persistence.repository;

public interface StatusCount {
    String getStatus();
    Long getTotal();
}
