package com.app.starter1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Starter1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
