package com.app.starter1.dto;

import lombok.Data;

@Data
public class ClienteForm {
    private String name;
    private String nit;
    private String phone;
    private String email;
    private String address;
    private String contact;
    private String position;
    private String status;
    private String type;
}
