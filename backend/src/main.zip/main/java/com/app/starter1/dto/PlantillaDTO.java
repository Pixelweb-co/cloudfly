package com.app.starter1.dto;

import lombok.Data;

import java.util.List;

@Data
public class PlantillaDTO {

        private String nom;
        private String valor;
        private Long id_orden;

}

