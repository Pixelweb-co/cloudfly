package com.app.starter1.dto;

import lombok.Data;

import java.util.List;

@Data
public class PlantillaVRequest {
    private String equimentlist;
    private String templateName;

}

