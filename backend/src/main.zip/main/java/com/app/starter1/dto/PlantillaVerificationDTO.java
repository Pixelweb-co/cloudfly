package com.app.starter1.dto;

import lombok.Data;

@Data
public class PlantillaVerificationDTO {

        private String id_plantilla;
        private String equipment;
        private String id_grupo;
        private String option;
        private String value;

}

