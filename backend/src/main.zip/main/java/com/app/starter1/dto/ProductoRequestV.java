package com.app.starter1.dto;

import lombok.Data;

@Data
public class ProductoRequestV {
    private Boolean verification;
}

