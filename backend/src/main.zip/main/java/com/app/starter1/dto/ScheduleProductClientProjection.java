package com.app.starter1.dto;

public interface ScheduleProductClientProjection {
    Long getId();
    String getDate();
    String getStatus();
    String getBrand();
    String getModel();
    String getNombreProducto();
    String getPlacaProducto();
    String getNombreCliente();
}
