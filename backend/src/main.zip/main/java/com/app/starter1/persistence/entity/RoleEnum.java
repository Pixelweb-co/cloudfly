package com.app.starter1.persistence.entity;

public enum RoleEnum {
    SUPERADMIN,
    BIOMEDICAL,
    ADMIN,
    USER,
}
