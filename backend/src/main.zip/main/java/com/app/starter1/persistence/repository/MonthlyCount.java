package com.app.starter1.persistence.repository;

public interface MonthlyCount {
    Integer getMonth();
    Long getTotal();
}
