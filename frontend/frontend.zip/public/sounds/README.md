# Notification Sound

Para que funcionen las notificaciones de audio, necesitas agregar un archivo de sonido:

1. Descargar un sonido de notificación (formato MP3)
2. Colocarlo en: `frontend/public/sounds/notification.mp3`

Puedes usar sitios como:
- https://notificationsounds.com/
- https://mixkit.co/free-sound-effects/notification/

O puedes comentar esa línea en `SocketContext.tsx` si no quieres sonido.
