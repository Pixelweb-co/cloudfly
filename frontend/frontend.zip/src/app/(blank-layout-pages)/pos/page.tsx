'use client'
import PosComponent from '@/views/apps/pos'
import React from 'react'

export default function page() {
  return (
    <PosComponent />
  )
}
