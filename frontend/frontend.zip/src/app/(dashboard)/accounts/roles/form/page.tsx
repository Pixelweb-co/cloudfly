import RoleForm from '@/views/apps/roles/form/RoleForm'

const CreateRolePage = () => {
    return <RoleForm id="new" />
}

export default CreateRolePage
