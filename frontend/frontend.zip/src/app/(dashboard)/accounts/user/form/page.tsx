'use client'
import RegisterV3 from '@/views/pages/auth/RegisterV3'

const RegisterPage = () => {
  // Vars
  return <RegisterV3 id={''} />
}

export default RegisterPage
