import ModuleListTable from '@/views/settings/modules/list/ModuleListTable'

export default function ModulesPage() {
    return <ModuleListTable />
}
