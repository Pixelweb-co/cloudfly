import PlanListTable from '@/views/settings/plans/list/PlanListTable'

const PlansPage = () => {
    return <PlanListTable />
}

export default PlansPage
