'use client'

import React from 'react'
import SubscriptionListTable from '@/views/settings/subscriptions/list/SubscriptionListTable'

const SubscriptionsPage = () => {
    return <SubscriptionListTable />
}

export default SubscriptionsPage
