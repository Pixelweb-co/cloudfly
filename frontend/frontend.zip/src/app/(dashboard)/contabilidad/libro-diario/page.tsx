import LibroDiarioView from '@/views/apps/contabilidad/libro-diario'

export const metadata = {
    title: 'Libro Diario - Contabilidad',
    description: 'Libro Diario contable con movimientos cronológicos'
}

export default function LibroDiarioPage() {
    return <LibroDiarioView />
}
