// Component Imports
import HomeDashboard from '@/views/dashboards/home'

const DashboardHome = () => {
  return <HomeDashboard />
}

export default DashboardHome
