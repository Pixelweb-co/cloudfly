import ChatbotSettings from '@/views/apps/settings/chatbot'

const ChatbotSettingsPage = () => {
    return <ChatbotSettings />
}

export default ChatbotSettingsPage
