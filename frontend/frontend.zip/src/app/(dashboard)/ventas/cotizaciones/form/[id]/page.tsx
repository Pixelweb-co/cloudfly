'use client'

import QuoteForm from '@views/apps/ventas/cotizaciones/form/QuoteForm'

const QuoteEditPage = () => {
    return <QuoteForm />
}

export default QuoteEditPage
