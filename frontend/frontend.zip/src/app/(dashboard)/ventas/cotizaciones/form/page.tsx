'use client'

import QuoteForm from '@views/apps/ventas/cotizaciones/form/QuoteForm'

const QuoteFormPage = () => {
    return <QuoteForm />
}

export default QuoteFormPage
