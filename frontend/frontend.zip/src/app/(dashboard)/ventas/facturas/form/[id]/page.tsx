'use client'

import InvoiceForm from '@views/apps/ventas/facturas/form/InvoiceForm'

const InvoiceEditPage = () => {
    return <InvoiceForm />
}

export default InvoiceEditPage
