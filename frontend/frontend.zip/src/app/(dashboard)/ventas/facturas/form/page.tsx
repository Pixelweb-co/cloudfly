'use client'

import InvoiceForm from '@views/apps/ventas/facturas/form/InvoiceForm'

const InvoiceFormPage = () => {
    return <InvoiceForm />
}

export default InvoiceFormPage
