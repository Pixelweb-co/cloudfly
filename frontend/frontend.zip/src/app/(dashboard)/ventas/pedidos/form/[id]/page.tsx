'use client'

import OrderForm from '@views/apps/ventas/pedidos/form/OrderForm'

const OrderViewPage = () => {
    return <OrderForm />
}

export default OrderViewPage
