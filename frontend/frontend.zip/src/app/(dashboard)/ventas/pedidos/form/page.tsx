'use client'

import OrderForm from '@views/apps/ventas/pedidos/form/OrderForm'

const OrderFormPage = () => {
    return <OrderForm />
}

export default OrderFormPage
