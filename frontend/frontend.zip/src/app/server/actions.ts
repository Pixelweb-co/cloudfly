/**
 * ! The server actions below are used to fetch the static data from the fake-db. If you're using an ORM
 * ! (Object-Relational Mapping) or a database, you can swap the code below with your own database queries.
 */

'use server'



export const getEcommerceData = async () => {
  return []
}

export const getAcademyData = async () => {
  return []
}

export const getLogisticsData = async () => {
  return []
}

export const getInvoiceData = async () => {
  return []
}

export const getUserData = async () => {
  return []
}

export const getPermissionsData = async () => {
  return []
}

export const getProfileData = async () => {
  return []
}

export const getFaqData = async () => {
  return []
}

export const getPricingData = async () => {
  return []
}

export const getStatisticsData = async () => {
  return []
}
