"""
Comprehensive tests for AIAdService.
Tests cover: ad generation, API error handling, response parsing, and prompt building.
"""
import unittest
from unittest.mock import patch, MagicMock
import json
from services.ai_ad_service import AIAdService, AIAdGenerationException


class TestAIAdService(unittest.TestCase):
    """Test suite for AIAdService."""

    def setUp(self):
        """Set up test fixtures."""
        self.service = AIAdService()
        self.test_product = {
            "productName": "Producto de Prueba",
            "description": "Descripción del producto de prueba",
            "price": 100000,
            "salePrice": 90000
        }

    @patch('services.ai_ad_service.requests.post')
    def test_generate_ad_success(self, mock_post):
        """Test successful AI ad generation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [
                {
                    "message": {
                        "content": json.dumps({
                            "headline": "¡Oferta Especial!",
                            "primary_text": "Increíble producto a buen precio",
                            "description": "Producto de calidad",
                            "cta": "Comprar ahora"
                        })
                    }
                }
            ]
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = self.service.generate_ad(self.test_product)

        self.assertIsInstance(result, dict)
        self.assertIn("headline", result)
        self.assertIn("primary_text", result)
        self.assertIn("description", result)
        self.assertIn("cta", result)
        self.assertEqual(result["cta"], "Comprar ahora")

    @patch('services.ai_ad_service.requests.post')
    def test_generate_ad_timeout(self, mock_post):
        """Test AI ad generation with timeout."""
        import requests as req
        mock_post.side_effect = req.Timeout("Request timed out")

        with self.assertRaises(AIAdGenerationException) as context:
            self.service.generate_ad(self.test_product)

        self.assertIn("Timeout", str(context.exception))

    @patch('services.ai_ad_service.requests.post')
    def test_generate_ad_http_error(self, mock_post):
        """Test AI ad generation with HTTP error."""
        import requests as req
        mock_response = MagicMock()
        mock_response.status_code = 429
        mock_post.side_effect = req.HTTPError(response=mock_response)

        with self.assertRaises(AIAdGenerationException) as context:
            self.service.generate_ad(self.test_product)

        self.assertIn("429", str(context.exception))

    @patch('services.ai_ad_service.requests.post')
    def test_generate_ad_invalid_json_response(self, mock_post):
        """Test AI ad generation with invalid JSON in response."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [
                {
                    "message": {
                        "content": "This is not valid JSON"
                    }
                }
            ]
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        with self.assertRaises(AIAdGenerationException) as context:
            self.service.generate_ad(self.test_product)

        self.assertIn("JSON", str(context.exception))

    @patch('services.ai_ad_service.requests.post')
    def test_generate_ad_missing_fields(self, mock_post):
        """Test AI ad generation with missing required fields."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [
                {
                    "message": {
                        "content": json.dumps({
                            "headline": "Only headline present"
                            # Missing primary_text, description, cta
                        })
                    }
                }
            ]
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        with self.assertRaises(AIAdGenerationException) as context:
            self.service.generate_ad(self.test_product)

        self.assertIn("Missing required field", str(context.exception))

    def test_build_prompt(self):
        """Test prompt building with product data."""
        prompt = self.service._build_prompt(self.test_product)

        self.assertIn("Producto de Prueba", prompt)
        self.assertIn("Descripción del producto de prueba", prompt)
        self.assertIn("90.000", prompt)
        self.assertIn("Meta", prompt)
        self.assertIn("JSON", prompt)

    def test_build_prompt_without_sale_price(self):
        """Test prompt building when salePrice is not available."""
        product_no_sale = {
            "productName": "Producto Sin Oferta",
            "description": "Descripción",
            "price": 50000
        }

        prompt = self.service._build_prompt(product_no_sale)

        self.assertIn("Producto Sin Oferta", prompt)
        self.assertIn("50.000", prompt)

    def test_build_prompt_with_minimal_product(self):
        """Test prompt building with minimal product data."""
        minimal_product = {"productName": "Mínimo"}

        prompt = self.service._build_prompt(minimal_product)

        self.assertIn("Mínimo", prompt)

    def test_service_initialization(self):
        """Test that AIAdService initializes correctly."""
        self.assertIsNotNone(self.service.api_url)
        self.assertIsNotNone(self.service.api_key)
        self.assertEqual(self.service.headers["Content-Type"], "application/json")
        self.assertIn("Authorization", self.service.headers)

    @patch('services.ai_ad_service.requests.post')
    def test_generate_ad_api_called_with_correct_payload(self, mock_post):
        """Test that API is called with correct payload structure."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [{
                "message": {
                    "content": json.dumps({
                        "headline": "Test",
                        "primary_text": "Test",
                        "description": "Test",
                        "cta": "Test"
                    })
                }
            }]
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        self.service.generate_ad(self.test_product)

        # Verify API was called
        mock_post.assert_called_once()

        # Verify payload structure
        call_args = mock_post.call_args
        payload = call_args[1].get('json', call_args[0][1] if len(call_args[0]) > 1 else None)

        self.assertIn("model", payload)
        self.assertIn("messages", payload)
        self.assertIn("temperature", payload)
        self.assertIn("max_tokens", payload)

    @patch('services.ai_ad_service.requests.post')
    def test_generate_ad_with_empty_product(self, mock_post):
        """Test AI ad generation with empty product dict."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "choices": [{
                "message": {
                    "content": json.dumps({
                        "headline": "Generic Ad",
                        "primary_text": "Generic content",
                        "description": "Generic description",
                        "cta": "Learn more"
                    })
                }
            }]
        }
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = self.service.generate_ad({})

        self.assertIsInstance(result, dict)
        self.assertIn("headline", result)


class TestAIAdGenerationException(unittest.TestCase):
    """Test AIAdGenerationException."""

    def test_exception_message(self):
        """Test exception can be raised with message."""
        with self.assertRaises(AIAdGenerationException):
            raise AIAdGenerationException("Test error message")

    def test_exception_inheritance(self):
        """Test exception inherits from Exception."""
        self.assertTrue(issubclass(AIAdGenerationException, Exception))


if __name__ == '__main__':
    unittest.main()
