"""
Acceptance Criteria Tests for CLOUD-68: Dockerfile for Marketing Agent

These tests verify all acceptance criteria for the Dockerfile:
1. Dockerfile created in marketing_agent/ directory
2. Image builds without errors
3. Container runs and connects to APIs (config loads correctly)
4. Environment variables configurable at runtime
5. Logs output to stdout/stderr (PYTHONUNBUFFERED=1)
6. Graceful shutdown on SIGTERM (signal handlers registered)
7. Non-root user (security best practice)
8. Dependencies installed correctly
"""

import subprocess
import sys
import os
import time

IMAGE_NAME = "marketing-agent:test"


def run_command(cmd, timeout=60):
    """Run a shell command and return (exit_code, stdout, stderr)."""
    result = subprocess.run(
        cmd,
        shell=True,
        capture_output=True,
        text=True,
        timeout=timeout,
        errors="replace"
    )
    return result.returncode, result.stdout.strip() if result.stdout else "", result.stderr.strip() if result.stderr else ""


def test_01_dockerfile_exists():
    """AC1: Dockerfile exists in marketing_agent/ directory."""
    dockerfile_path = os.path.join(os.path.dirname(__file__), "Dockerfile")
    assert os.path.isfile(dockerfile_path), f"Dockerfile not found at {dockerfile_path}"
    print("[PASS] AC1: Dockerfile exists in marketing_agent/ directory")


def test_02_image_builds():
    """AC2: Image builds without errors."""
    exit_code, stdout, stderr = run_command(
        f"cd {os.path.dirname(__file__)} && docker build -t {IMAGE_NAME} .",
        timeout=120
    )
    assert exit_code == 0, f"Docker build failed:\n{stderr}\n{stdout}"
    # Verify the image exists
    exit_code2, stdout2, stderr2 = run_command(f"docker images {IMAGE_NAME} --format '{{{{.Repository}}}}:{{{{.Tag}}}}'")
    assert exit_code2 == 0, f"Image not found after build: {stderr2}"
    assert "marketing-agent:test" in stdout2, f"Image not found: {stdout2}"
    print("[PASS] AC2: Image builds without errors")


def test_03_dependencies_installed():
    """AC3: All dependencies from requirements.txt are installed."""
    exit_code, stdout, stderr = run_command(
        f"docker run --rm {IMAGE_NAME} python -c "
        "\"import requests; import mysql.connector; import dotenv; print('OK')\""
    )
    assert exit_code == 0, f"Dependencies not installed:\n{stderr}"
    assert "OK" in stdout
    print("[PASS] AC3: All dependencies installed (requests, mysql-connector-python, python-dotenv)")


def test_04_config_loads():
    """AC4: Application config loads correctly."""
    exit_code, stdout, stderr = run_command(
        f"docker run --rm {IMAGE_NAME} python -c "
        "\"from config import Config; print(Config.BACKEND_URL)\""
    )
    assert exit_code == 0, f"Config failed to load:\n{stderr}"
    assert "http://backend:8080" in stdout
    print("[PASS] AC4: Application config loads correctly")


def test_05_main_class_loads():
    """AC5: MarketingAgent class loads correctly."""
    exit_code, stdout, stderr = run_command(
        f"docker run --rm {IMAGE_NAME} python -c "
        "\"from main import MarketingAgent; print('OK')\""
    )
    assert exit_code == 0, f"MarketingAgent class failed to load:\n{stderr}"
    assert "OK" in stdout
    print("[PASS] AC5: MarketingAgent class loads correctly")


def test_06_env_vars_configurable():
    """AC6: Environment variables are configurable at runtime."""
    exit_code, stdout, stderr = run_command(
        f"docker run --rm "
        f"-e DB_HOST=mysql "
        f"-e DB_PASSWORD=test123 "
        f"-e BACKEND_API_KEY=secret-key "
        f"-e TENANT_ID=42 "
        f"{IMAGE_NAME} python -c "
        "\"from config import Config; "
        "print('DB_HOST:', Config.DB_HOST); "
        "print('DB_PASSWORD:', Config.DB_PASSWORD); "
        "print('BACKEND_API_KEY:', Config.BACKEND_API_KEY); "
        "print('TENANT_ID:', Config.TENANT_ID)\""
    )
    assert exit_code == 0, f"Env var override failed:\n{stderr}"
    assert "DB_HOST: mysql" in stdout
    assert "DB_PASSWORD: test123" in stdout
    assert "BACKEND_API_KEY: secret-key" in stdout
    assert "TENANT_ID: 42" in stdout
    print("[PASS] AC6: Environment variables configurable at runtime")


def test_07_non_root_user():
    """AC7: Container runs as non-root user."""
    exit_code, stdout, stderr = run_command(
        f"docker run --rm {IMAGE_NAME} python -c "
        "\"import os; print(os.getuid())\""
    )
    assert exit_code == 0, f"UID check failed:\n{stderr}"
    uid = int(stdout.strip())
    assert uid != 0, f"Container is running as root (UID={uid})"
    assert uid == 999, f"Expected UID 999 (appuser), got {uid}"
    print(f"[PASS] AC7: Container runs as non-root user (UID={uid})")


def test_08_python_unbuffered():
    """AC8: PYTHONUNBUFFERED is set for stdout/stderr logging."""
    exit_code, stdout, stderr = run_command(
        f"docker run --rm {IMAGE_NAME} python -c "
        "\"import os; print(os.environ.get('PYTHONUNBUFFERED', 'NOT SET'))\""
    )
    assert exit_code == 0, f"PYTHONUNBUFFERED check failed:\n{stderr}"
    assert "1" in stdout, f"PYTHONUNBUFFERED not set: {stdout}"
    print("[PASS] AC8: PYTHONUNBUFFERED=1 (logs output to stdout/stderr)")


def test_09_signal_handlers_registered():
    """AC9: Signal handlers for SIGTERM/SIGINT are registered in main.py."""
    main_py_path = os.path.join(os.path.dirname(__file__), "main.py")
    with open(main_py_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    assert "signal.signal(signal.SIGTERM" in content, "SIGTERM handler not registered in main.py"
    assert "signal.signal(signal.SIGINT" in content, "SIGINT handler not registered in main.py"
    assert "_shutdown_requested" in content, "Shutdown flag not found in main.py"
    print("[PASS] AC9: Signal handlers for graceful shutdown are registered")


def test_10_healthcheck_configured():
    """AC10: HEALTHCHECK is configured in the Dockerfile."""
    exit_code, stdout, stderr = run_command(
        f"docker inspect --format='{{{{.Config.Healthcheck}}}}' {IMAGE_NAME}"
    )
    assert exit_code == 0, f"Healthcheck inspect failed:\n{stderr}"
    # Healthcheck output contains CMD-SHELL and interval info when configured
    assert "CMD-SHELL" in stdout or "sys.exit" in stdout, f"No HEALTHCHECK configured: {stdout}"
    print("[PASS] AC10: HEALTHCHECK is configured in the Dockerfile")


def test_11_docker_compose_valid():
    """AC11: docker-compose.yml is valid and has stop_grace_period."""
    compose_path = os.path.join(os.path.dirname(__file__), "docker-compose.yml")
    assert os.path.isfile(compose_path), f"docker-compose.yml not found at {compose_path}"
    
    with open(compose_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    assert "stop_grace_period: 30s" in content, "stop_grace_period not set in docker-compose.yml"
    assert "stop_signal: SIGTERM" in content, "stop_signal not set in docker-compose.yml"
    print("[PASS] AC11: docker-compose.yml has graceful shutdown configuration")


def test_12_dockerfile_content():
    """AC12: Dockerfile contains all required elements."""
    dockerfile_path = os.path.join(os.path.dirname(__file__), "Dockerfile")
    with open(dockerfile_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    required_elements = [
        "FROM python:3.11-slim",
        "COPY requirements.txt",
        "pip install",
        "COPY . .",
        "BACKEND_URL",
        "EVOLUTION_API_URL",
        "DB_HOST",
        'CMD ["python", "main.py"]',
        "PYTHONUNBUFFERED",
        "PYTHONDONTWRITEBYTECODE",
        "appuser",
        "USER appuser",
        "HEALTHCHECK",
    ]
    
    for element in required_elements:
        assert element in content, f"Dockerfile missing required element: {element}"
    
    print("[PASS] AC12: Dockerfile contains all required elements")


def run_all_tests():
    """Run all acceptance criteria tests."""
    tests = [
        test_01_dockerfile_exists,
        test_02_image_builds,
        test_03_dependencies_installed,
        test_04_config_loads,
        test_05_main_class_loads,
        test_06_env_vars_configurable,
        test_07_non_root_user,
        test_08_python_unbuffered,
        test_09_signal_handlers_registered,
        test_10_healthcheck_configured,
        test_11_docker_compose_valid,
        test_12_dockerfile_content,
    ]
    
    passed = 0
    failed = 0
    
    print("=" * 60)
    print("[TEST] CLOUD-68: Dockerfile Acceptance Criteria Tests")
    print("=" * 60)
    
    for test in tests:
        try:
            test()
            passed += 1
        except AssertionError as e:
            print(f"[FAIL] {test.__name__}: {e}")
            failed += 1
        except Exception as e:
            print(f"[FAIL] {test.__name__}: Unexpected error: {e}")
            failed += 1
    
    print("=" * 60)
    print(f"[RESULT] Results: {passed} passed, {failed} failed, {passed + failed} total")
    print("=" * 60)
    
    if failed > 0:
        sys.exit(1)
    else:
        print("[SUCCESS] All acceptance criteria met! CLOUD-68 is ready for closure.")
        sys.exit(0)


if __name__ == "__main__":
    run_all_tests()
