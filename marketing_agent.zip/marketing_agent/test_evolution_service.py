import unittest
from unittest.mock import patch, MagicMock
from services.evolution_service import EvolutionService
from models.campaign import CampaignMessage

class TestEvolutionService(unittest.TestCase):
    """Unit tests for EvolutionService"""
    
    def setUp(self):
        self.service = EvolutionService()
        self.text_message = CampaignMessage(text="Test message")
        self.media_message = CampaignMessage(
            text="Test message with media",
            media_url="https://example.com/image.jpg",
            media_type="image",
            caption="Test caption"
        )
    
    @patch('services.evolution_service.requests.post')
    @patch('services.evolution_service.time.sleep')
    def test_send_campaign_text_success(self, mock_sleep, mock_post):
        """Test successful text message sending"""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service.send_campaign("573001234567", self.text_message)
        
        self.assertTrue(result)
        # Should call presence update and send text
        self.assertEqual(mock_post.call_count, 2)
    
    @patch('services.evolution_service.requests.post')
    @patch('services.evolution_service.time.sleep')
    def test_send_campaign_media_success(self, mock_sleep, mock_post):
        """Test successful media message sending"""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service.send_campaign("573001234567", self.media_message)
        
        self.assertTrue(result)
        # Should call presence update and send media
        self.assertEqual(mock_post.call_count, 2)
    
    @patch('services.evolution_service.requests.post')
    @patch('services.evolution_service.time.sleep')
    def test_send_campaign_error(self, mock_sleep, mock_post):
        """Test error handling during message sending"""
        mock_post.side_effect = Exception("API Error")
        
        result = self.service.send_campaign("573001234567", self.text_message)
        
        self.assertFalse(result)
    
    @patch('services.evolution_service.requests.post')
    def test_send_presence(self, mock_post):
        """Test presence update sending"""
        self.service._send_presence("573001234567", "composing")
        
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        self.assertIn("updatePresence", call_args[0][0])
    
    @patch('services.evolution_service.requests.post')
    def test_send_text(self, mock_post):
        """Test text message sending"""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service._send_text("573001234567", "Test message")
        
        self.assertTrue(result)
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        self.assertIn("sendText", call_args[0][0])
    
    @patch('services.evolution_service.requests.post')
    def test_send_media(self, mock_post):
        """Test media message sending"""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service._send_media("573001234567", self.media_message)
        
        self.assertTrue(result)
        mock_post.assert_called_once()
        call_args = mock_post.call_args
        self.assertIn("sendMedia", call_args[0][0])


if __name__ == '__main__':
    unittest.main()
