"""
Comprehensive tests for EvolutionService.
Tests cover: presence sending, text messages, media messages, error handling, and anti-spam delays.
"""
import unittest
from unittest.mock import patch, MagicMock, call
import time
from services.evolution_service import EvolutionService
from models.campaign import CampaignMessage


class TestEvolutionService(unittest.TestCase):
    """Test suite for EvolutionService."""

    def setUp(self):
        """Set up test fixtures."""
        self.service = EvolutionService()
        self.test_phone = "573001234567"
        self.text_message = CampaignMessage(
            text="Test message",
            media_url=None,
            media_type=None,
            caption=None
        )
        self.media_message = CampaignMessage(
            text="Test message with media",
            media_url="https://example.com/image.jpg",
            media_type="image",
            caption="Test caption"
        )

    @patch('services.evolution_service.requests.post')
    @patch('services.evolution_service.time.sleep')
    def test_send_campaign_text_only(self, mock_sleep, mock_post):
        """Test sending a text-only campaign message."""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = self.service.send_campaign(self.test_phone, self.text_message)

        self.assertTrue(result)
        # Should have called presence + text
        self.assertEqual(mock_post.call_count, 2)
        mock_sleep.assert_called()  # Anti-spam delay

    @patch('services.evolution_service.requests.post')
    @patch('services.evolution_service.time.sleep')
    def test_send_campaign_with_media(self, mock_sleep, mock_post):
        """Test sending a campaign message with media."""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = self.service.send_campaign(self.test_phone, self.media_message)

        self.assertTrue(result)
        # Should have called presence + media
        self.assertEqual(mock_post.call_count, 2)
        mock_sleep.assert_called()  # Anti-spam delay

    @patch('services.evolution_service.requests.post')
    @patch('services.evolution_service.time.sleep')
    def test_send_campaign_http_error(self, mock_sleep, mock_post):
        """Test campaign sending when HTTP error occurs."""
        mock_post.side_effect = Exception("Connection error")

        result = self.service.send_campaign(self.test_phone, self.text_message)

        self.assertFalse(result)

    @patch('services.evolution_service.requests.post')
    def test_send_presence(self, mock_post):
        """Test presence indicator sending."""
        self.service._send_presence(self.test_phone, "composing")

        mock_post.assert_called_once()
        call_args = mock_post.call_args
        url = call_args[0][0]
        payload = call_args[1].get('json', call_args[0][1] if len(call_args[0]) > 1 else None)

        self.assertIn("updatePresence", url)
        self.assertIn("composing", str(payload))

    @patch('services.evolution_service.requests.post')
    def test_send_text(self, mock_post):
        """Test text message sending."""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = self.service._send_text(self.test_phone, "Hello World")

        self.assertTrue(result)
        mock_post.assert_called_once()
        mock_response.raise_for_status.assert_called_once()

    @patch('services.evolution_service.requests.post')
    def test_send_media(self, mock_post):
        """Test media message sending."""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        result = self.service._send_media(self.test_phone, self.media_message)

        self.assertTrue(result)
        mock_post.assert_called_once()
        mock_response.raise_for_status.assert_called_once()

    @patch('services.evolution_service.requests.post')
    def test_send_text_http_error(self, mock_post):
        """Test text message sending with HTTP error."""
        import requests as req
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_post.side_effect = req.HTTPError(response=mock_response)

        with self.assertRaises(req.HTTPError):
            self.service._send_text(self.test_phone, "Hello World")

    @patch('services.evolution_service.requests.post')
    def test_send_media_http_error(self, mock_post):
        """Test media message sending with HTTP error."""
        import requests as req
        mock_response = MagicMock()
        mock_response.status_code = 500
        mock_post.side_effect = req.HTTPError(response=mock_response)

        with self.assertRaises(req.HTTPError):
            self.service._send_media(self.test_phone, self.media_message)

    def test_service_initialization(self):
        """Test that EvolutionService initializes with correct config."""
        self.assertIsNotNone(self.service.api_url)
        self.assertIsNotNone(self.service.api_key)
        self.assertIsNotNone(self.service.instance)
        self.assertEqual(self.service.headers["Content-Type"], "application/json")
        self.assertIn("apikey", self.service.headers)

    @patch('services.evolution_service.requests.post')
    @patch('services.evolution_service.time.sleep')
    def test_anti_spam_delay_between_presence_and_message(self, mock_sleep, mock_post):
        """Test that anti-spam delay is applied between presence and message."""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        self.service.send_campaign(self.test_phone, self.text_message)

        # Verify sleep was called (anti-spam delay)
        mock_sleep.assert_called()
        # The delay should be between 1.5 and 3.5 seconds
        sleep_args = mock_sleep.call_args[0][0]
        self.assertGreaterEqual(sleep_args, 1.5)
        self.assertLessEqual(sleep_args, 3.5)

    @patch('services.evolution_service.requests.post')
    def test_presence_failure_does_not_stop_campaign(self, mock_post):
        """Test that presence update failure doesn't prevent message sending."""
        # First call (presence) raises exception
        # Second call (text) succeeds
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.side_effect = [Exception("Presence failed"), mock_response]

        with patch('services.evolution_service.time.sleep'):
            result = self.service.send_campaign(self.test_phone, self.text_message)

        # Should still succeed because presence failure is caught
        self.assertTrue(result)


class TestEvolutionServiceIntegration(unittest.TestCase):
    """Integration-style tests for EvolutionService."""

    def setUp(self):
        self.service = EvolutionService()

    @patch('services.evolution_service.requests.post')
    @patch('services.evolution_service.time.sleep')
    def test_multiple_contacts_sequential_sending(self, mock_sleep, mock_post):
        """Test sending to multiple contacts with anti-spam delays."""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response

        contacts = ["573001234567", "573001234568", "573001234569"]
        message = CampaignMessage(text="Test", media_url=None, media_type=None, caption=None)

        results = []
        for phone in contacts:
            result = self.service.send_campaign(phone, message)
            results.append(result)

        # All should succeed
        self.assertTrue(all(results))
        # Should have 2 API calls per contact (presence + message)
        self.assertEqual(mock_post.call_count, len(contacts) * 2)

    @patch('services.evolution_service.requests.post')
    @patch('services.evolution_service.time.sleep')
    def test_campaign_with_mixed_success_and_failure(self, mock_sleep, mock_post):
        """Test campaign where some messages fail and some succeed."""
        mock_response = MagicMock()
        mock_response.raise_for_status = MagicMock()

        # First call succeeds, second fails
        mock_post.side_effect = [
            mock_response, mock_response,  # First contact: presence + text
            Exception("Failed"),            # Second contact: presence fails
            mock_response, mock_response,  # Third contact: presence + text
        ]

        contacts = ["573001234567", "573001234568", "573001234569"]
        message = CampaignMessage(text="Test", media_url=None, media_type=None, caption=None)

        results = {"sent": 0, "failed": 0}
        for phone in contacts:
            try:
                result = self.service.send_campaign(phone, message)
                if result:
                    results["sent"] += 1
                else:
                    results["failed"] += 1
            except Exception:
                results["failed"] += 1

        # At least some should succeed
        self.assertGreater(results["sent"], 0)


if __name__ == '__main__':
    unittest.main()
