import unittest
from unittest.mock import patch, MagicMock
import time
from main import MarketingAgent
from services.product_service import ProductNotFoundException

class TestMarketingAgentIntegration(unittest.TestCase):
    """Integration tests for MarketingAgent"""
    
    def setUp(self):
        self.agent = MarketingAgent()
        self.mock_product = {
            "id": 1,
            "productName": "Test Product",
            "description": "Test description",
            "price": 100000,
            "salePrice": 90000,
            "status": "ACTIVE",
            "imageIds": [1],
            "images": [{"id": 1, "url": "https://example.com/image.jpg"}],
            "image_url": "https://example.com/image.jpg"
        }
        self.mock_contacts = [
            {"id": 1, "name": "Contact 1", "phone": "573001234567"},
            {"id": 2, "name": "Contact 2", "phone": "573001234568"}
        ]
    
    @patch('main.mysql.connector.connect')
    @patch('services.evolution_service.requests.post')
    @patch('services.product_service.requests.get')
    @patch('main.time.sleep')
    def test_full_campaign_flow(self, mock_sleep, mock_product_get, mock_evolution_post, mock_db):
        """Test complete campaign execution flow"""
        # Mock product service
        mock_product_response = MagicMock()
        mock_product_response.json.return_value = {"data": [self.mock_product]}
        mock_product_response.raise_for_status = MagicMock()
        mock_product_get.return_value = mock_product_response
        
        # Mock evolution service
        mock_evolution_response = MagicMock()
        mock_evolution_response.raise_for_status = MagicMock()
        mock_evolution_post.return_value = mock_evolution_response
        
        # Mock database
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = self.mock_contacts
        mock_conn = MagicMock()
        mock_conn.cursor.return_value = mock_cursor
        mock_db.return_value = mock_conn
        
        # Run the agent
        self.agent.run()
        
        # Verify product was fetched
        mock_product_get.assert_called_once()
        
        # Verify messages were sent to all contacts
        self.assertGreater(mock_evolution_post.call_count, 0)
    
    @patch('main.mysql.connector.connect')
    @patch('services.evolution_service.requests.post')
    @patch('services.product_service.requests.get')
    @patch('main.time.sleep')
    def test_campaign_with_no_contacts(self, mock_sleep, mock_product_get, mock_evolution_post, mock_db):
        """Test campaign execution with no contacts"""
        # Mock product service
        mock_product_response = MagicMock()
        mock_product_response.json.return_value = {"data": [self.mock_product]}
        mock_product_response.raise_for_status = MagicMock()
        mock_product_get.return_value = mock_product_response
        
        # Mock database with no contacts
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = []
        mock_conn = MagicMock()
        mock_conn.cursor.return_value = mock_cursor
        mock_db.return_value = mock_conn
        
        # Run the agent
        self.agent.run()
        
        # Verify no messages were sent
        mock_evolution_post.assert_not_called()
    
    @patch('services.product_service.requests.get')
    def test_campaign_with_no_product(self, mock_product_get):
        """Test campaign execution when no valid product exists"""
        # Mock empty product response
        mock_product_response = MagicMock()
        mock_product_response.json.return_value = {"data": []}
        mock_product_response.raise_for_status = MagicMock()
        mock_product_get.return_value = mock_product_response
        
        # Run the agent - should handle gracefully
        self.agent.run()
        
        # Verify product was attempted to be fetched
        mock_product_get.assert_called_once()
    
    @patch('main.mysql.connector.connect')
    @patch('services.evolution_service.requests.post')
    @patch('services.product_service.requests.get')
    @patch('main.time.sleep')
    def test_anti_spam_delays(self, mock_sleep, mock_product_get, mock_evolution_post, mock_db):
        """Test that anti-spam delays are applied"""
        # Mock product service
        mock_product_response = MagicMock()
        mock_product_response.json.return_value = {"data": [self.mock_product]}
        mock_product_response.raise_for_status = MagicMock()
        mock_product_get.return_value = mock_product_response
        
        # Mock evolution service
        mock_evolution_response = MagicMock()
        mock_evolution_response.raise_for_status = MagicMock()
        mock_evolution_post.return_value = mock_evolution_response
        
        # Mock database
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = self.mock_contacts
        mock_conn = MagicMock()
        mock_conn.cursor.return_value = mock_cursor
        mock_db.return_value = mock_conn
        
        # Run the agent
        self.agent.run()
        
        # Verify sleep was called (anti-spam delays)
        self.assertGreater(mock_sleep.call_count, 0)
    
    def test_get_active_contacts(self):
        """Test contact retrieval from database"""
        with patch('main.mysql.connector.connect') as mock_db:
            mock_cursor = MagicMock()
            mock_cursor.fetchall.return_value = self.mock_contacts
            mock_conn = MagicMock()
            mock_conn.cursor.return_value = mock_cursor
            mock_db.return_value = mock_conn
            
            contacts = self.agent.get_active_contacts(1, 1)
            
            self.assertEqual(len(contacts), 2)
            self.assertEqual(contacts[0]["name"], "Contact 1")


if __name__ == '__main__':
    unittest.main()
