"""
Integration tests for Marketing Agent.
Tests the full campaign flow: Product -> Campaign -> Evolution -> Database.
"""
import unittest
from unittest.mock import patch, MagicMock, PropertyMock
import json
from main import MarketingAgent
from services.product_service import ProductService, ProductNotFoundException
from services.campaign_service import CampaignService
from services.evolution_service import EvolutionService
from services.ai_ad_service import AIAdService, AIAdGenerationException
from models.campaign import CampaignMessage


class TestMarketingAgentIntegration(unittest.TestCase):
    """Integration tests for the full marketing agent flow."""

    def setUp(self):
        """Set up test fixtures."""
        self.agent = MarketingAgent()
        self.test_product = {
            "id": 1,
            "productName": "Producto de Prueba",
            "description": "Descripción del producto de prueba",
            "price": 100000,
            "salePrice": 90000,
            "status": "ACTIVE",
            "imageIds": [1],
            "images": [{"id": 1, "url": "https://example.com/image.jpg"}],
            "image_url": "https://example.com/image.jpg"
        }
        self.test_contacts = [
            {"id": 1, "name": "Contact 1", "email": "test1@test.com", "phone": "573001234567"},
            {"id": 2, "name": "Contact 2", "email": "test2@test.com", "phone": "573001234568"},
        ]

    @patch('main.mysql.connector.connect')
    @patch('services.evolution_service.requests.post')
    @patch('services.product_service.requests.get')
    @patch('services.evolution_service.time.sleep')
    def test_full_campaign_flow(self, mock_sleep, mock_product_get, mock_evolution_post, mock_db):
        """Test the complete campaign execution flow."""
        # Mock product API response
        mock_product_response = MagicMock()
        mock_product_response.json.return_value = {"data": [self.test_product]}
        mock_product_response.raise_for_status = MagicMock()
        mock_product_get.return_value = mock_product_response

        # Mock Evolution API response
        mock_evolution_response = MagicMock()
        mock_evolution_response.raise_for_status = MagicMock()
        mock_evolution_post.return_value = mock_evolution_response

        # Mock database connection
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = self.test_contacts
        mock_conn = MagicMock()
        mock_conn.cursor.return_value = mock_cursor
        mock_db.return_value = mock_conn

        # Run the agent
        self.agent.run(generate_ad=False)

        # Verify product API was called
        mock_product_get.assert_called_once()

        # Verify Evolution API was called for each contact (presence + message per contact)
        self.assertEqual(mock_evolution_post.call_count, len(self.test_contacts) * 2)

        # Verify database was queried
        mock_db.assert_called()

    @patch('main.mysql.connector.connect')
    @patch('services.product_service.requests.get')
    def test_campaign_no_contacts(self, mock_product_get, mock_db):
        """Test campaign when no contacts are found."""
        # Mock product API response
        mock_product_response = MagicMock()
        mock_product_response.json.return_value = {"data": [self.test_product]}
        mock_product_response.raise_for_status = MagicMock()
        mock_product_get.return_value = mock_product_response

        # Mock database connection - no contacts
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = []
        mock_conn = MagicMock()
        mock_conn.cursor.return_value = mock_cursor
        mock_db.return_value = mock_conn

        # Run the agent - should exit gracefully
        self.agent.run(generate_ad=False)

        # Verify product API was called
        mock_product_get.assert_called_once()

    @patch('services.product_service.requests.get')
    def test_campaign_product_not_found(self, mock_product_get):
        """Test campaign when no valid product is found."""
        # Mock product API response - no products
        mock_product_response = MagicMock()
        mock_product_response.json.return_value = {"data": []}
        mock_product_response.raise_for_status = MagicMock()
        mock_product_get.return_value = mock_product_response

        # Run the agent - should handle gracefully
        self.agent.run(generate_ad=False)

        # Verify product API was called
        mock_product_get.assert_called_once()

    @patch('main.mysql.connector.connect')
    @patch('services.evolution_service.requests.post')
    @patch('services.product_service.requests.get')
    @patch('services.evolution_service.time.sleep')
    def test_campaign_with_ai_ad_generation(self, mock_sleep, mock_product_get, mock_evolution_post, mock_db):
        """Test campaign with AI ad generation enabled."""
        # Mock product API response
        mock_product_response = MagicMock()
        mock_product_response.json.return_value = {"data": [self.test_product]}
        mock_product_response.raise_for_status = MagicMock()
        mock_product_get.return_value = mock_product_response

        # Mock Evolution API response
        mock_evolution_response = MagicMock()
        mock_evolution_response.raise_for_status = MagicMock()
        mock_evolution_post.return_value = mock_evolution_response

        # Mock database connection
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = self.test_contacts[:1]  # Just one contact
        mock_conn = MagicMock()
        mock_conn.cursor.return_value = mock_cursor
        mock_db.return_value = mock_conn

        # Mock AI ad service
        with patch.object(self.agent, 'ai_ad_service') as mock_ai:
            mock_ai.generate_ad.return_value = {
                "headline": "AI Generated Headline",
                "primary_text": "AI Generated Content",
                "description": "AI Description",
                "cta": "Comprar"
            }

            # Run the agent with AI ad generation
            self.agent.run(generate_ad=True)

            # Verify AI ad was generated
            mock_ai.generate_ad.assert_called_once_with(self.test_product)

    @patch('main.mysql.connector.connect')
    @patch('services.evolution_service.requests.post')
    @patch('services.product_service.requests.get')
    @patch('services.evolution_service.time.sleep')
    def test_campaign_skips_contacts_without_phone(self, mock_sleep, mock_product_get, mock_evolution_post, mock_db):
        """Test that contacts without phone numbers are skipped."""
        # Mock product API response
        mock_product_response = MagicMock()
        mock_product_response.json.return_value = {"data": [self.test_product]}
        mock_product_response.raise_for_status = MagicMock()
        mock_product_get.return_value = mock_product_response

        # Mock Evolution API response
        mock_evolution_response = MagicMock()
        mock_evolution_response.raise_for_status = MagicMock()
        mock_evolution_post.return_value = mock_evolution_response

        # Mock database connection - contacts without phones
        contacts_no_phone = [
            {"id": 1, "name": "No Phone", "email": "test@test.com", "phone": ""},
            {"id": 2, "name": "Has Phone", "email": "test2@test.com", "phone": "573001234567"},
        ]
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = contacts_no_phone
        mock_conn = MagicMock()
        mock_conn.cursor.return_value = mock_cursor
        mock_db.return_value = mock_conn

        # Run the agent
        self.agent.run(generate_ad=False)

        # Only the contact with phone should have messages sent
        # 1 contact * 2 calls (presence + message) = 2
        self.assertEqual(mock_evolution_post.call_count, 2)


class TestCampaignMessageModel(unittest.TestCase):
    """Test CampaignMessage data class."""

    def test_campaign_message_with_media(self):
        """Test CampaignMessage with media URL."""
        msg = CampaignMessage(
            text="Test",
            media_url="https://example.com/image.jpg",
            media_type="image",
            caption="Caption"
        )
        self.assertTrue(msg.has_media())
        self.assertEqual(msg.media_url, "https://example.com/image.jpg")

    def test_campaign_message_without_media(self):
        """Test CampaignMessage without media URL."""
        msg = CampaignMessage(text="Test")
        self.assertFalse(msg.has_media())
        self.assertIsNone(msg.media_url)

    def test_campaign_message_empty_media_url(self):
        """Test CampaignMessage with empty media URL."""
        msg = CampaignMessage(text="Test", media_url="")
        self.assertFalse(msg.has_media())


class TestProductService(unittest.TestCase):
    """Test ProductService filtering logic."""

    def setUp(self):
        self.service = ProductService()

    @patch('services.product_service.requests.get')
    def test_valid_product_with_all_fields(self, mock_get):
        """Test that a valid product is correctly identified."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "data": [{
                "id": 1,
                "productName": "Valid Product",
                "description": "Valid description",
                "price": 100000,
                "status": "ACTIVE",
                "imageIds": [1, 2],
                "images": [{"id": 1, "url": "https://example.com/image.jpg"}]
            }]
        }
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        result = self.service.get_active_product_with_image(1)

        self.assertEqual(result["productName"], "Valid Product")
        self.assertEqual(result["image_url"], "https://example.com/image.jpg")

    @patch('services.product_service.requests.get')
    def test_inactive_product_filtered_out(self, mock_get):
        """Test that inactive products are filtered out."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "data": [{
                "id": 1,
                "productName": "Inactive Product",
                "description": "Description",
                "price": 100000,
                "status": "INACTIVE",
                "imageIds": [1],
                "images": [{"id": 1, "url": "https://example.com/image.jpg"}]
            }]
        }
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)

    @patch('services.product_service.requests.get')
    def test_product_without_description_filtered_out(self, mock_get):
        """Test that products without description are filtered out."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "data": [{
                "id": 1,
                "productName": "No Description Product",
                "description": None,
                "price": 100000,
                "status": "ACTIVE",
                "imageIds": [1],
                "images": [{"id": 1, "url": "https://example.com/image.jpg"}]
            }]
        }
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)

    @patch('services.product_service.requests.get')
    def test_product_without_images_filtered_out(self, mock_get):
        """Test that products without images are filtered out."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "data": [{
                "id": 1,
                "productName": "No Images Product",
                "description": "Description",
                "price": 100000,
                "status": "ACTIVE",
                "imageIds": [],
                "images": []
            }]
        }
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response

        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)


class TestCampaignService(unittest.TestCase):
    """Test CampaignService message formatting."""

    def setUp(self):
        self.service = CampaignService()

    def test_build_campaign_message_with_sale_price(self):
        """Test message uses salePrice when available."""
        product = {
            "productName": "Test Product",
            "description": "Test description",
            "price": 100000,
            "salePrice": 90000,
            "image_url": "https://example.com/image.jpg"
        }

        result = self.service.build_campaign_message(product)

        self.assertIn("$90.000", result.text)
        self.assertEqual(result.media_url, "https://example.com/image.jpg")
        self.assertEqual(result.media_type, "image")

    def test_build_campaign_message_without_sale_price(self):
        """Test message uses regular price when salePrice not available."""
        product = {
            "productName": "Test Product",
            "description": "Test description",
            "price": 100000,
            "salePrice": None,
            "image_url": ""
        }

        result = self.service.build_campaign_message(product)

        self.assertIn("$100.000", result.text)
        self.assertIsNone(result.media_url)
        self.assertIsNone(result.media_type)

    def test_format_colombian_peso_standard(self):
        """Test standard Colombian Peso formatting."""
        self.assertEqual(self.service._format_colombian_peso(100000), "$100.000")
        self.assertEqual(self.service._format_colombian_peso(99999), "$99.999")
        self.assertEqual(self.service._format_colombian_peso(1000000), "$1.000.000")

    def test_format_colombian_peso_edge_cases(self):
        """Test edge cases for Colombian Peso formatting."""
        self.assertEqual(self.service._format_colombian_peso(0), "$0")
        self.assertEqual(self.service._format_colombian_peso(1), "$1")
        self.assertEqual(self.service._format_colombian_peso(10000000), "$10.000.000")

    def test_message_contains_whatsapp_markdown(self):
        """Test that message uses WhatsApp Markdown formatting."""
        product = {
            "productName": "Test Product",
            "description": "Test description",
            "price": 100000,
            "salePrice": 90000,
            "image_url": "https://example.com/image.jpg"
        }

        result = self.service.build_campaign_message(product)

        # Product name should be bold (wrapped in *)
        self.assertIn("*Test Product*", result.text)
        # Should contain call to action
        self.assertIn("¡Contáctanos para más información!", result.text)


if __name__ == '__main__':
    unittest.main()
