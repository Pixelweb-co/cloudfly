import unittest
from unittest.mock import patch, MagicMock
from services.product_service import ProductService, ProductNotFoundException
from services.campaign_service import CampaignService
from models.campaign import CampaignMessage

class TestProductService(unittest.TestCase):
    @patch('services.product_service.requests.get')
    def test_get_active_product_with_image_success(self, mock_get):
        # Mock response
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "data": [
                {
                    "id": 1,
                    "productName": "Test Product",
                    "description": "Test description",
                    "price": 100000,
                    "status": "ACTIVE",
                    "imageIds": [1],
                    "images": [{"id": 1, "url": "https://example.com/image.jpg"}]
                }
            ]
        }
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        service = ProductService()
        product = service.get_active_product_with_image(1)
        
        self.assertEqual(product["productName"], "Test Product")
        self.assertEqual(product["image_url"], "https://example.com/image.jpg")
    
    @patch('services.product_service.requests.get')
    def test_get_active_product_no_active_product(self, mock_get):
        # Mock response with no active products
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "data": [
                {
                    "id": 1,
                    "productName": "Test Product",
                    "description": "Test description",
                    "price": 100000,
                    "status": "INACTIVE",
                    "imageIds": [1],
                    "images": [{"id": 1, "url": "https://example.com/image.jpg"}]
                }
            ]
        }
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        service = ProductService()
        with self.assertRaises(ProductNotFoundException):
            service.get_active_product_with_image(1)

class TestCampaignService(unittest.TestCase):
    def test_build_campaign_message(self):
        service = CampaignService()
        product = {
            "productName": "Test Product",
            "description": "Test description",
            "price": 100000,
            "salePrice": 90000,
            "image_url": "https://example.com/image.jpg"
        }
        
        message = service.build_campaign_message(product)
        
        self.assertIsInstance(message, CampaignMessage)
        self.assertIn("Test Product", message.text)
        self.assertIn("90.000", message.text)
        self.assertEqual(message.media_url, "https://example.com/image.jpg")
        self.assertEqual(message.media_type, "image")

if __name__ == '__main__':
    unittest.main()
