"""
Integration tests for Meta Ads creation flow.
Tests the complete flow from product data to Meta ad creation.
"""

import unittest
from unittest.mock import patch, MagicMock
import sys
import os

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.meta_ads_service import MetaAdsService, MetaAdsException
from services.ai_ad_service import AIAdService
from services.product_service import ProductService


class TestMetaAdsIntegration(unittest.TestCase):
    """Integration tests for Meta Ads creation flow."""

    def setUp(self):
        """Set up test fixtures."""
        # Mock Config
        self.config_patcher = patch('services.meta_ads_service.Config')
        self.mock_config = self.config_patcher.start()
        self.mock_config.META_ACCESS_TOKEN = "test_token_123"
        self.mock_config.META_AD_ACCOUNT_ID = "act_123456789"
        self.mock_config.META_PAGE_ID = "987654321"
        
        self.meta_service = MetaAdsService()
        
        self.test_product = {
            "productName": "Smartphone XYZ",
            "description": "Smartphone de última generación con cámara de 108MP",
            "price": 1500000,
            "salePrice": 1299900,
            "image_url": "https://example.com/smartphone.jpg"
        }
        
        self.test_ad_content = {
            "headline": "¡Smartphone XYZ en Oferta!",
            "primary_text": "No te pierdas esta increíble oferta en el Smartphone XYZ. "
                          "Cámara de 108MP, batería de larga duración y el mejor precio del mercado. "
                          "¡Compra ahora y recíbelo en tu casa!",
            "description": "Smartphone de última generación",
            "cta": "SHOP_NOW"
        }

    def tearDown(self):
        """Clean up patches."""
        self.config_patcher.stop()

    @patch.object(MetaAdsService, 'create_ad')
    @patch.object(MetaAdsService, 'create_ad_set')
    @patch.object(MetaAdsService, 'create_campaign')
    @patch.object(MetaAdsService, 'create_ad_creative')
    @patch.object(MetaAdsService, 'upload_image')
    def test_full_meta_ad_creation_flow(self, mock_upload, mock_creative,
                                        mock_campaign, mock_adset, mock_ad):
        """Test the complete Meta ad creation flow."""
        # Setup mocks
        mock_upload.return_value = "img_hash_abc123"
        mock_creative.return_value = "creative_xyz789"
        mock_campaign.return_value = "campaign_123"
        mock_adset.return_value = "adset_456"
        mock_ad.return_value = "ad_789"
        
        # Execute
        result = self.meta_service.create_complete_ad(
            product=self.test_product,
            ad_content=self.test_ad_content,
            daily_budget_cop=100000
        )
        
        # Verify all steps were called
        mock_upload.assert_called_once_with("https://example.com/smartphone.jpg")
        mock_creative.assert_called_once()
        mock_campaign.assert_called_once()
        mock_adset.assert_called_once()
        mock_ad.assert_called_once()
        
        # Verify result structure
        self.assertIn("campaign_id", result)
        self.assertIn("ad_set_id", result)
        self.assertIn("ad_id", result)
        self.assertIn("creative_id", result)
        self.assertIn("image_hash", result)
        self.assertIn("product_name", result)
        self.assertIn("daily_budget_cop", result)
        
        # Verify values
        self.assertEqual(result["campaign_id"], "campaign_123")
        self.assertEqual(result["ad_set_id"], "adset_456")
        self.assertEqual(result["ad_id"], "ad_789")
        self.assertEqual(result["creative_id"], "creative_xyz789")
        self.assertEqual(result["image_hash"], "img_hash_abc123")
        self.assertEqual(result["product_name"], "Smartphone XYZ")
        self.assertEqual(result["daily_budget_cop"], 100000)

    @patch.object(MetaAdsService, 'create_ad')
    @patch.object(MetaAdsService, 'create_ad_set')
    @patch.object(MetaAdsService, 'create_campaign')
    @patch.object(MetaAdsService, 'create_ad_creative')
    @patch.object(MetaAdsService, 'upload_image')
    def test_meta_ad_with_minimal_content(self, mock_upload, mock_creative,
                                          mock_campaign, mock_adset, mock_ad):
        """Test Meta ad creation with minimal ad content."""
        mock_upload.return_value = "img_hash"
        mock_creative.return_value = "creative"
        mock_campaign.return_value = "campaign"
        mock_adset.return_value = "adset"
        mock_ad.return_value = "ad"
        
        minimal_ad_content = {
            "headline": "Producto",
            "primary_text": "Texto",
            "description": "Desc",
            "cta": "LEARN_MORE"
        }
        
        result = self.meta_service.create_complete_ad(
            product=self.test_product,
            ad_content=minimal_ad_content,
            daily_budget_cop=50000
        )
        
        self.assertIsNotNone(result)
        self.assertEqual(result["daily_budget_cop"], 50000)

    @patch.object(MetaAdsService, 'create_ad')
    @patch.object(MetaAdsService, 'create_ad_set')
    @patch.object(MetaAdsService, 'create_campaign')
    @patch.object(MetaAdsService, 'create_ad_creative')
    @patch.object(MetaAdsService, 'upload_image')
    def test_meta_ad_budget_conversion(self, mock_upload, mock_creative,
                                       mock_campaign, mock_adset, mock_ad):
        """Test that budget is correctly converted from COP to cents."""
        mock_upload.return_value = "hash"
        mock_creative.return_value = "creative"
        mock_campaign.return_value = "campaign"
        mock_adset.return_value = "adset"
        mock_ad.return_value = "ad"
        
        # Test with 100,000 COP
        self.meta_service.create_complete_ad(
            product=self.test_product,
            ad_content=self.test_ad_content,
            daily_budget_cop=100000
        )
        
        # Verify ad set was called with budget in cents (100000 * 100 = 10,000,000)
        call_args = mock_adset.call_args
        kwargs = call_args[1] if call_args[1] else {}
        self.assertEqual(kwargs.get("daily_budget"), 10000000)

    def test_meta_ad_fails_without_image(self):
        """Test that Meta ad creation fails without product image."""
        product_no_image = {
            "productName": "Test Product",
            "description": "Test"
        }
        
        with self.assertRaises(MetaAdsException) as context:
            self.meta_service.create_complete_ad(
                product=product_no_image,
                ad_content=self.test_ad_content
            )
        
        self.assertIn("image_url", str(context.exception))

    @patch.object(MetaAdsService, 'upload_image')
    def test_meta_ad_fails_on_upload_error(self, mock_upload):
        """Test that Meta ad creation fails gracefully on upload error."""
        mock_upload.side_effect = MetaAdsException("Upload failed")
        
        with self.assertRaises(MetaAdsException):
            self.meta_service.create_complete_ad(
                product=self.test_product,
                ad_content=self.test_ad_content
            )

    @patch.object(MetaAdsService, 'create_ad_set')
    @patch.object(MetaAdsService, 'create_campaign')
    @patch.object(MetaAdsService, 'create_ad_creative')
    @patch.object(MetaAdsService, 'upload_image')
    def test_meta_ad_fails_on_campaign_error(self, mock_upload, mock_creative,
                                             mock_campaign, mock_adset):
        """Test that Meta ad creation fails gracefully on campaign error."""
        mock_upload.return_value = "hash"
        mock_creative.return_value = "creative"
        mock_campaign.side_effect = MetaAdsException("Campaign creation failed")
        
        with self.assertRaises(MetaAdsException):
            self.meta_service.create_complete_ad(
                product=self.test_product,
                ad_content=self.test_ad_content
            )


class TestMetaAdsWithAIIntegration(unittest.TestCase):
    """Integration tests combining AI ad generation with Meta Ads."""

    def setUp(self):
        """Set up test fixtures."""
        self.config_patcher_ai = patch('services.ai_ad_service.Config')
        self.config_patcher_meta = patch('services.meta_ads_service.Config')
        
        mock_ai_config = self.config_patcher_ai.start()
        mock_ai_config.OPENROUTER_API_KEY = "test_openrouter_key"
        
        mock_meta_config = self.config_patcher_meta.start()
        mock_meta_config.META_ACCESS_TOKEN = "test_token"
        mock_meta_config.META_AD_ACCOUNT_ID = "act_123"
        mock_meta_config.META_PAGE_ID = "456"

    def tearDown(self):
        """Clean up patches."""
        self.config_patcher_ai.stop()
        self.config_patcher_meta.stop()

    @patch('services.ai_ad_service.requests.post')
    @patch.object(MetaAdsService, 'create_complete_ad')
    def test_ai_ad_to_meta_ad_flow(self, mock_meta_create, mock_ai_post):
        """Test the flow from AI ad generation to Meta ad creation."""
        # Mock AI service response
        mock_ai_response = MagicMock()
        mock_ai_response.json.return_value = {
            "choices": [{
                "message": {
                    "content": '{"headline": "AI Generated", "primary_text": "AI text", "description": "AI desc", "cta": "SHOP_NOW"}'
                }
            }]
        }
        mock_ai_response.raise_for_status = MagicMock()
        mock_ai_post.return_value = mock_ai_response
        
        # Mock Meta service response
        mock_meta_create.return_value = {
            "campaign_id": "camp_123",
            "ad_id": "ad_123"
        }
        
        # Generate AI ad
        ai_service = AIAdService()
        product = {"productName": "Test", "description": "Test desc", "price": 100000}
        ad_content = ai_service.generate_ad(product)
        
        # Verify AI ad was generated
        self.assertIsNotNone(ad_content)
        self.assertIn("headline", ad_content)
        
        # Create Meta ad with AI content
        meta_service = MetaAdsService()
        result = meta_service.create_complete_ad(
            product={**product, "image_url": "https://example.com/img.jpg"},
            ad_content=ad_content
        )
        
        # Verify Meta ad was created
        self.assertIsNotNone(result)
        self.assertEqual(result["campaign_id"], "camp_123")


class TestMetaAdsTargeting(unittest.TestCase):
    """Tests for Meta Ads targeting configuration."""

    def setUp(self):
        """Set up test fixtures."""
        self.config_patcher = patch('services.meta_ads_service.Config')
        self.mock_config = self.config_patcher.start()
        self.mock_config.META_ACCESS_TOKEN = "test_token"
        self.mock_config.META_AD_ACCOUNT_ID = "act_123"
        self.mock_config.META_PAGE_ID = "456"
        self.service = MetaAdsService()

    def tearDown(self):
        """Clean up patches."""
        self.config_patcher.stop()

    @patch('services.meta_ads_service.requests.post')
    def test_colombia_targeting(self, mock_post):
        """Test that ad set targets Colombia."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": "adset_123"}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        self.service.create_ad_set(
            name="Test",
            campaign_id="camp_123"
        )
        
        # Verify targeting
        call_args = mock_post.call_args
        data = call_args[1].get('json', call_args[0][1] if len(call_args[0]) > 1 else None)
        targeting = data.get("targeting", {})
        geo = targeting.get("geo_locations", {})
        
        self.assertEqual(geo.get("countries"), ["CO"])
        self.assertIn("home", geo.get("location_types", []))

    @patch('services.meta_ads_service.requests.post')
    def test_platform_targeting(self, mock_post):
        """Test that ad set targets Facebook and Instagram."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": "adset_123"}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        self.service.create_ad_set(
            name="Test",
            campaign_id="camp_123"
        )
        
        call_args = mock_post.call_args
        data = call_args[1].get('json', call_args[0][1] if len(call_args[0]) > 1 else None)
        targeting = data.get("targeting", {})
        
        self.assertIn("facebook", targeting.get("publisher_platforms", []))
        self.assertIn("instagram", targeting.get("publisher_platforms", []))


if __name__ == '__main__':
    unittest.main()
