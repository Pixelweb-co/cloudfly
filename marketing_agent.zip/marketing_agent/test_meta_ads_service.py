"""
Comprehensive tests for MetaAdsService.
Tests cover: image upload, ad creative creation, campaign creation,
ad set creation, ad creation, and complete ad flow.
"""

import unittest
from unittest.mock import patch, MagicMock, PropertyMock
import json
import sys
import os

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from services.meta_ads_service import MetaAdsService, MetaAdsException


class TestMetaAdsService(unittest.TestCase):
    """Test suite for MetaAdsService."""

    def setUp(self):
        """Set up test fixtures with mocked config."""
        # Mock the Config class to provide test values
        self.config_patcher = patch('services.meta_ads_service.Config')
        self.mock_config = self.config_patcher.start()
        self.mock_config.META_ACCESS_TOKEN = "test_token_123"
        self.mock_config.META_AD_ACCOUNT_ID = "act_123456789"
        self.mock_config.META_PAGE_ID = "987654321"
        
        self.service = MetaAdsService()
        
        self.test_product = {
            "productName": "Producto de Prueba",
            "description": "Descripción del producto",
            "price": 100000,
            "image_url": "https://example.com/image.jpg"
        }
        
        self.test_ad_content = {
            "headline": "¡Oferta Especial!",
            "primary_text": "Increíble producto a buen precio",
            "description": "Producto de calidad",
            "cta": "LEARN_MORE"
        }

    def tearDown(self):
        """Clean up patches."""
        self.config_patcher.stop()

    def test_service_initialization(self):
        """Test that MetaAdsService initializes correctly."""
        self.assertIsNotNone(self.service.access_token)
        self.assertEqual(self.service.access_token, "test_token_123")
        self.assertEqual(self.service.ad_account_id, "act_123456789")
        self.assertEqual(self.service.page_id, "987654321")

    def test_service_initialization_adds_act_prefix(self):
        """Test that ad_account_id gets 'act_' prefix if missing."""
        self.mock_config.META_AD_ACCOUNT_ID = "123456789"
        service = MetaAdsService()
        self.assertEqual(service.ad_account_id, "act_123456789")

    def test_service_initialization_missing_token(self):
        """Test that service raises exception when token is missing."""
        self.mock_config.META_ACCESS_TOKEN = ""
        with self.assertRaises(MetaAdsException) as context:
            MetaAdsService()
        self.assertIn("META_ACCESS_TOKEN", str(context.exception))

    def test_service_initialization_missing_ad_account(self):
        """Test that service raises exception when ad account is missing."""
        self.mock_config.META_AD_ACCOUNT_ID = ""
        with self.assertRaises(MetaAdsException) as context:
            MetaAdsService()
        self.assertIn("META_AD_ACCOUNT_ID", str(context.exception))

    def test_service_initialization_missing_page_id(self):
        """Test that service raises exception when page ID is missing."""
        self.mock_config.META_PAGE_ID = ""
        with self.assertRaises(MetaAdsException) as context:
            MetaAdsService()
        self.assertIn("META_PAGE_ID", str(context.exception))

    @patch('services.meta_ads_service.requests.get')
    @patch('services.meta_ads_service.requests.post')
    def test_upload_image_success(self, mock_post, mock_get):
        """Test successful image upload."""
        # Mock image download
        mock_image_response = MagicMock()
        mock_image_response.content = b"fake_image_data"
        mock_image_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_image_response
        
        # Mock Meta API response
        mock_api_response = MagicMock()
        mock_api_response.json.return_value = {
            "images": {
                "image.jpg": {
                    "hash": "abc123hash",
                    "url": "https://facebook.com/image.jpg"
                }
            }
        }
        mock_api_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_api_response
        
        result = self.service.upload_image("https://example.com/image.jpg")
        
        self.assertEqual(result, "abc123hash")
        mock_get.assert_called_once_with("https://example.com/image.jpg", timeout=30)

    @patch('services.meta_ads_service.requests.get')
    def test_upload_image_download_failure(self, mock_get):
        """Test image upload when download fails."""
        import requests as req
        mock_get.side_effect = req.RequestException("Download failed")
        
        with self.assertRaises(MetaAdsException) as context:
            self.service.upload_image("https://example.com/image.jpg")
        
        self.assertIn("Failed to download image", str(context.exception))

    @patch('services.meta_ads_service.requests.get')
    @patch('services.meta_ads_service.requests.post')
    def test_upload_image_no_hash_in_response(self, mock_post, mock_get):
        """Test image upload when response has no hash."""
        # Mock image download
        mock_image_response = MagicMock()
        mock_image_response.content = b"fake_image_data"
        mock_image_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_image_response
        
        # Mock Meta API response without hash
        mock_api_response = MagicMock()
        mock_api_response.json.return_value = {"images": {}}
        mock_api_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_api_response
        
        with self.assertRaises(MetaAdsException) as context:
            self.service.upload_image("https://example.com/image.jpg")
        
        self.assertIn("No image hash", str(context.exception))

    @patch('services.meta_ads_service.requests.post')
    def test_create_ad_creative_success(self, mock_post):
        """Test successful ad creative creation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": "creative_123"}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service.create_ad_creative(
            name="Test Creative",
            image_hash="abc123hash",
            headline="Test Headline",
            primary_text="Test text",
            description="Test description",
            cta="LEARN_MORE"
        )
        
        self.assertEqual(result, "creative_123")

    @patch('services.meta_ads_service.requests.post')
    def test_create_ad_creative_failure(self, mock_post):
        """Test ad creative creation failure."""
        mock_response = MagicMock()
        mock_response.json.return_value = {}  # No ID
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        with self.assertRaises(MetaAdsException) as context:
            self.service.create_ad_creative(
                name="Test Creative",
                image_hash="abc123hash",
                headline="Test",
                primary_text="Test",
                description="Test",
                cta="LEARN_MORE"
            )
        
        self.assertIn("Failed to create ad creative", str(context.exception))

    @patch('services.meta_ads_service.requests.post')
    def test_create_campaign_success(self, mock_post):
        """Test successful campaign creation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": "campaign_123"}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service.create_campaign(name="Test Campaign")
        
        self.assertEqual(result, "campaign_123")
        
        # Verify campaign is created with PAUSED status
        call_args = mock_post.call_args
        data = call_args[1].get('json', call_args[0][1] if len(call_args[0]) > 1 else None)
        self.assertEqual(data.get("status"), "PAUSED")

    @patch('services.meta_ads_service.requests.post')
    def test_create_campaign_failure(self, mock_post):
        """Test campaign creation failure."""
        mock_response = MagicMock()
        mock_response.json.return_value = {}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        with self.assertRaises(MetaAdsException) as context:
            self.service.create_campaign(name="Test Campaign")
        
        self.assertIn("Failed to create campaign", str(context.exception))

    @patch('services.meta_ads_service.requests.post')
    def test_create_ad_set_success(self, mock_post):
        """Test successful ad set creation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": "adset_123"}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service.create_ad_set(
            name="Test Ad Set",
            campaign_id="campaign_123",
            daily_budget=500000  # $500,000 COP in cents
        )
        
        self.assertEqual(result, "adset_123")
        
        # Verify Colombia targeting
        call_args = mock_post.call_args
        data = call_args[1].get('json', call_args[0][1] if len(call_args[0]) > 1 else None)
        targeting = data.get("targeting", {})
        geo_locations = targeting.get("geo_locations", {})
        self.assertEqual(geo_locations.get("countries"), ["CO"])

    @patch('services.meta_ads_service.requests.post')
    def test_create_ad_set_failure(self, mock_post):
        """Test ad set creation failure."""
        mock_response = MagicMock()
        mock_response.json.return_value = {}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        with self.assertRaises(MetaAdsException) as context:
            self.service.create_ad_set(
                name="Test Ad Set",
                campaign_id="campaign_123"
            )
        
        self.assertIn("Failed to create ad set", str(context.exception))

    @patch('services.meta_ads_service.requests.post')
    def test_create_ad_success(self, mock_post):
        """Test successful ad creation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"id": "ad_123"}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service.create_ad(
            name="Test Ad",
            ad_set_id="adset_123",
            creative_id="creative_123"
        )
        
        self.assertEqual(result, "ad_123")

    @patch('services.meta_ads_service.requests.post')
    def test_create_ad_failure(self, mock_post):
        """Test ad creation failure."""
        mock_response = MagicMock()
        mock_response.json.return_value = {}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        with self.assertRaises(MetaAdsException) as context:
            self.service.create_ad(
                name="Test Ad",
                ad_set_id="adset_123",
                creative_id="creative_123"
            )
        
        self.assertIn("Failed to create ad", str(context.exception))

    @patch.object(MetaAdsService, 'create_ad')
    @patch.object(MetaAdsService, 'create_ad_set')
    @patch.object(MetaAdsService, 'create_campaign')
    @patch.object(MetaAdsService, 'create_ad_creative')
    @patch.object(MetaAdsService, 'upload_image')
    def test_create_complete_ad_success(self, mock_upload, mock_creative,
                                       mock_campaign, mock_adset, mock_ad):
        """Test successful complete ad creation flow."""
        mock_upload.return_value = "image_hash_123"
        mock_creative.return_value = "creative_123"
        mock_campaign.return_value = "campaign_123"
        mock_adset.return_value = "adset_123"
        mock_ad.return_value = "ad_123"
        
        result = self.service.create_complete_ad(
            product=self.test_product,
            ad_content=self.test_ad_content,
            daily_budget_cop=50000
        )
        
        self.assertEqual(result["image_hash"], "image_hash_123")
        self.assertEqual(result["creative_id"], "creative_123")
        self.assertEqual(result["campaign_id"], "campaign_123")
        self.assertEqual(result["ad_set_id"], "adset_123")
        self.assertEqual(result["ad_id"], "ad_123")
        self.assertEqual(result["product_name"], "Producto de Prueba")
        self.assertEqual(result["daily_budget_cop"], 50000)

    def test_create_complete_ad_missing_image_url(self):
        """Test complete ad creation fails without image_url."""
        product_no_image = {"productName": "Test"}
        
        with self.assertRaises(MetaAdsException) as context:
            self.service.create_complete_ad(
                product=product_no_image,
                ad_content=self.test_ad_content
            )
        
        self.assertIn("image_url", str(context.exception))

    @patch('services.meta_ads_service.requests.get')
    def test_get_ad_status_success(self, mock_get):
        """Test successful ad status retrieval."""
        mock_response = MagicMock()
        mock_response.json.return_value = {
            "id": "ad_123",
            "name": "Test Ad",
            "status": "PAUSED",
            "effective_status": "PAUSED",
            "created_time": "2024-01-01T00:00:00+0000"
        }
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        result = self.service.get_ad_status("ad_123")
        
        self.assertEqual(result["id"], "ad_123")
        self.assertEqual(result["status"], "PAUSED")

    @patch('services.meta_ads_service.requests.post')
    def test_activate_ad_success(self, mock_post):
        """Test successful ad activation."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"success": True}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service.activate_ad("ad_123")
        
        self.assertTrue(result)
        
        # Verify ACTIVE status is sent
        call_args = mock_post.call_args
        data = call_args[1].get('json', call_args[0][1] if len(call_args[0]) > 1 else None)
        self.assertEqual(data.get("status"), "ACTIVE")

    @patch('services.meta_ads_service.requests.post')
    def test_pause_ad_success(self, mock_post):
        """Test successful ad pausing."""
        mock_response = MagicMock()
        mock_response.json.return_value = {"success": True}
        mock_response.raise_for_status = MagicMock()
        mock_post.return_value = mock_response
        
        result = self.service.pause_ad("ad_123")
        
        self.assertTrue(result)
        
        # Verify PAUSED status is sent
        call_args = mock_post.call_args
        data = call_args[1].get('json', call_args[0][1] if len(call_args[0]) > 1 else None)
        self.assertEqual(data.get("status"), "PAUSED")

    @patch('services.meta_ads_service.requests.post')
    def test_rate_limit_retry(self, mock_post):
        """Test that rate limit errors trigger retry."""
        import requests as req
        
        # First call returns rate limit error
        mock_error_response = MagicMock()
        mock_error_response.status_code = 429
        mock_error_response.json.return_value = {
            "error": {"message": "Rate limit", "code": 32}
        }
        
        # Second call succeeds
        mock_success_response = MagicMock()
        mock_success_response.json.return_value = {"id": "campaign_123"}
        mock_success_response.raise_for_status = MagicMock()
        
        mock_post.side_effect = [
            req.HTTPError(response=mock_error_response),
            mock_success_response
        ]
        
        result = self.service.create_campaign(name="Test Campaign")
        
        self.assertEqual(result, "campaign_123")
        self.assertEqual(mock_post.call_count, 2)

    @patch('services.meta_ads_service.requests.post')
    def test_timeout_retry(self, mock_post):
        """Test that timeout errors trigger retry."""
        import requests as req
        
        # First call times out
        # Second call succeeds
        mock_success_response = MagicMock()
        mock_success_response.json.return_value = {"id": "campaign_123"}
        mock_success_response.raise_for_status = MagicMock()
        
        mock_post.side_effect = [
            req.Timeout("Timeout"),
            mock_success_response
        ]
        
        result = self.service.create_campaign(name="Test Campaign")
        
        self.assertEqual(result, "campaign_123")
        self.assertEqual(mock_post.call_count, 2)


class TestMetaAdsException(unittest.TestCase):
    """Test MetaAdsException."""

    def test_exception_message(self):
        """Test exception can be raised with message."""
        with self.assertRaises(MetaAdsException):
            raise MetaAdsException("Test error message")

    def test_exception_inheritance(self):
        """Test exception inherits from Exception."""
        self.assertTrue(issubclass(MetaAdsException, Exception))

    def test_exception_with_empty_message(self):
        """Test exception with empty message."""
        try:
            raise MetaAdsException("")
        except MetaAdsException as e:
            self.assertEqual(str(e), "")


if __name__ == '__main__':
    unittest.main()
