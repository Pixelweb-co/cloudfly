# test_placeholder.py
"""Placeholder test for marketing_agent package.
Ensures that the package can be imported and that generate_image_ad
raises an error when the required OPENROUTER_API_KEY is not set.
"""

import os
import pytest
from marketing_agent.ai_ad_service import generate_image_ad

def test_generate_image_ad_without_api_key(monkeypatch):
    # Ensure the environment variable is unset
    monkeypatch.delenv("OPENROUTER_API_KEY", raising=False)
    product = {"name": "Test Product", "description": "A test description"}
    with pytest.raises(RuntimeError) as excinfo:
        # Since generate_image_ad is async, we need to run it in an event loop
        import asyncio
        asyncio.run(generate_image_ad(product))
    assert "OPENROUTER_API_KEY not configured" in str(excinfo.value)
