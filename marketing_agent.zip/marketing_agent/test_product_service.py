import unittest
from unittest.mock import patch, MagicMock
from services.product_service import ProductService, ProductNotFoundException
from services.campaign_service import CampaignService
from models.campaign import CampaignMessage

class TestProductService(unittest.TestCase):
    """Unit tests for ProductService"""
    
    def setUp(self):
        self.service = ProductService()
        self.valid_product = {
            "id": 1,
            "productName": "Test Product",
            "description": "Test description",
            "price": 100000,
            "status": "ACTIVE",
            "imageIds": [1],
            "images": [{"id": 1, "url": "https://example.com/image.jpg"}]
        }
    
    @patch('services.product_service.requests.get')
    def test_get_active_product_success(self, mock_get):
        """Test successful product retrieval with valid product"""
        mock_response = MagicMock()
        mock_response.json.return_value = {"data": [self.valid_product]}
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        result = self.service.get_active_product_with_image(1)
        
        self.assertEqual(result["productName"], "Test Product")
        self.assertEqual(result["image_url"], "https://example.com/image.jpg")
    
    @patch('services.product_service.requests.get')
    def test_get_active_product_not_found(self, mock_get):
        """Test exception when no products exist"""
        mock_response = MagicMock()
        mock_response.json.return_value = {"data": []}
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)
    
    @patch('services.product_service.requests.get')
    def test_get_active_product_inactive_status(self, mock_get):
        """Test filtering out inactive products"""
        inactive_product = {**self.valid_product, "status": "INACTIVE"}
        mock_response = MagicMock()
        mock_response.json.return_value = {"data": [inactive_product]}
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)
    
    @patch('services.product_service.requests.get')
    def test_get_active_product_missing_description(self, mock_get):
        """Test filtering out products without description"""
        no_desc_product = {**self.valid_product, "description": None}
        mock_response = MagicMock()
        mock_response.json.return_value = {"data": [no_desc_product]}
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)
    
    @patch('services.product_service.requests.get')
    def test_get_active_product_empty_description(self, mock_get):
        """Test filtering out products with empty description"""
        empty_desc_product = {**self.valid_product, "description": "   "}
        mock_response = MagicMock()
        mock_response.json.return_value = {"data": [empty_desc_product]}
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)
    
    @patch('services.product_service.requests.get')
    def test_get_active_product_missing_images(self, mock_get):
        """Test filtering out products without images"""
        no_images_product = {**self.valid_product, "imageIds": []}
        mock_response = MagicMock()
        mock_response.json.return_value = {"data": [no_images_product]}
        mock_response.raise_for_status = MagicMock()
        mock_get.return_value = mock_response
        
        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)
    
    @patch('services.product_service.requests.get')
    def test_get_active_product_timeout(self, mock_get):
        """Test timeout handling"""
        import requests
        mock_get.side_effect = requests.Timeout()
        
        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)
    
    @patch('services.product_service.requests.get')
    def test_get_active_product_http_error(self, mock_get):
        """Test HTTP error handling"""
        import requests
        mock_get.side_effect = requests.HTTPError(response=MagicMock(status_code=500))
        
        with self.assertRaises(ProductNotFoundException):
            self.service.get_active_product_with_image(1)


class TestCampaignService(unittest.TestCase):
    """Unit tests for CampaignService"""
    
    def setUp(self):
        self.service = CampaignService()
        self.base_product = {
            "productName": "Producto de Prueba",
            "description": "Descripción del producto de prueba",
            "price": 100000,
            "salePrice": 90000,
            "image_url": "https://example.com/image.jpg"
        }
    
    def test_build_campaign_message_with_all_fields(self):
        """Test message building with complete product data"""
        result = self.service.build_campaign_message(self.base_product)
        
        self.assertIsInstance(result, CampaignMessage)
        self.assertIn("Producto de Prueba", result.text)
        self.assertIn("Descripción del producto", result.text)
        self.assertIn("$90.000", result.text)  # Uses salePrice
        self.assertEqual(result.media_url, "https://example.com/image.jpg")
        self.assertEqual(result.media_type, "image")
        self.assertIsNotNone(result.caption)
    
    def test_build_campaign_message_without_sale_price(self):
        """Test message uses regular price when salePrice not available"""
        product = {**self.base_product, "salePrice": None}
        result = self.service.build_campaign_message(product)
        
        self.assertIn("$100.000", result.text)
    
    def test_build_campaign_message_without_image(self):
        """Test message without image URL"""
        product = {**self.base_product, "image_url": ""}
        result = self.service.build_campaign_message(product)
        
        self.assertIsNone(result.media_url)
        self.assertIsNone(result.media_type)
        self.assertIsNone(result.caption)
    
    def test_build_campaign_message_missing_optional_fields(self):
        """Test message handles missing optional fields gracefully"""
        minimal_product = {
            "productName": "Producto Mínimo",
            "description": "Descripción",
            "price": 50000
        }
        result = self.service.build_campaign_message(minimal_product)
        
        self.assertIn("Producto Mínimo", result.text)
        self.assertIn("$50.000", result.text)
    
    def test_format_colombian_peso_standard(self):
        """Test standard price formatting"""
        self.assertEqual(self.service._format_colombian_peso(100000), "$100.000")
        self.assertEqual(self.service._format_colombian_peso(99999), "$99.999")
        self.assertEqual(self.service._format_colombian_peso(1000000), "$1.000.000")
    
    def test_format_colombian_peso_edge_cases(self):
        """Test edge cases for price formatting"""
        self.assertEqual(self.service._format_colombian_peso(0), "$0")
        self.assertEqual(self.service._format_colombian_peso(1), "$1")
        self.assertEqual(self.service._format_colombian_peso(10000000), "$10.000.000")
    
    def test_message_has_whatsapp_markdown_formatting(self):
        """Test that message uses WhatsApp Markdown formatting"""
        result = self.service.build_campaign_message(self.base_product)
        
        # Product name should be bold (wrapped in *)
        self.assertIn("*Producto de Prueba*", result.text)
    
    def test_message_contains_call_to_action(self):
        """Test that message includes call to action"""
        result = self.service.build_campaign_message(self.base_product)
        
        self.assertIn("¡Contáctanos para más información!", result.text)
    
    def test_campaign_message_dataclass(self):
        """Test CampaignMessage dataclass behavior"""
        msg = CampaignMessage(text="Test", media_url="http://test.com")
        
        self.assertTrue(msg.has_media())
        
        msg_no_media = CampaignMessage(text="Test")
        self.assertFalse(msg_no_media.has_media())


if __name__ == '__main__':
    unittest.main()
