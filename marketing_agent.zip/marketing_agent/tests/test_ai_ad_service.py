import pytest
import base64
from unittest.mock import AsyncMock, patch
from marketing_agent.ai_ad_service import generate_image_ad

@pytest.mark.asyncio
async def test_generate_image_ad_success():
    fake_image = b'PNGFAKEIMAGE'
    b64_image = base64.b64encode(fake_image).decode()
    mock_response = {
        "choices": [{"message": {"content": b64_image}}]
    }
    async def mock_post(*args, **kwargs):
        class MockResp:
            def raise_for_status(self):
                pass
            def json(self):
                return mock_response
        return MockResp()
    with patch('httpx.AsyncClient.post', new=mock_post):
        result = await generate_image_ad({"name": "Test", "description": "Desc"})
        assert result == fake_image

@pytest.mark.asyncio
async def test_generate_image_ad_invalid_response():
    mock_response = {"invalid": True}
    async def mock_post(*args, **kwargs):
        class MockResp:
            def raise_for_status(self):
                pass
            def json(self):
                return mock_response
        return MockResp()
    with patch('httpx.AsyncClient.post', new=mock_post):
        with pytest.raises(RuntimeError):
            await generate_image_ad({"name": "Test", "description": "Desc"})
