"""
Unit tests for CampaignService.

Tests cover:
- Message building with complete and partial product data
- Colombian Peso price formatting
- WhatsApp Markdown formatting
- CampaignMessage dataclass behavior
- Edge cases (missing fields, zero price, no image)
"""

import pytest
from services.campaign_service import CampaignService
from models.campaign import CampaignMessage


class TestCampaignService:
    """Comprehensive test suite for CampaignService"""

    def setup_method(self):
        """Set up test fixtures."""
        self.service = CampaignService()
        self.base_product = {
            "productName": "Producto de Prueba",
            "description": "Descripción del producto de prueba",
            "price": 100000,
            "salePrice": 90000,
            "image_url": "https://example.com/image.jpg"
        }

    def test_build_campaign_message_with_all_fields(self):
        """Test message building with complete product data"""
        result = self.service.build_campaign_message(self.base_product)

        assert isinstance(result, CampaignMessage)
        assert "Producto de Prueba" in result.text
        assert "Descripción del producto" in result.text
        assert "$90.000" in result.text  # Uses salePrice
        assert result.media_url == "https://example.com/image.jpg"
        assert result.media_type == "image"
        assert result.caption is not None

    def test_build_campaign_message_without_sale_price(self):
        """Test message uses regular price when salePrice not available"""
        product = {**self.base_product, "salePrice": None}
        result = self.service.build_campaign_message(product)

        assert "$100.000" in result.text

    def test_build_campaign_message_without_image(self):
        """Test message without image URL"""
        product = {**self.base_product, "image_url": ""}
        result = self.service.build_campaign_message(product)

        assert result.media_url is None
        assert result.media_type is None
        assert result.caption is None

    def test_build_campaign_message_missing_optional_fields(self):
        """Test message handles missing optional fields gracefully"""
        minimal_product = {
            "productName": "Producto Mínimo",
            "description": "Descripción",
            "price": 50000
        }
        result = self.service.build_campaign_message(minimal_product)

        assert "Producto Mínimo" in result.text
        assert "$50.000" in result.text

    def test_format_colombian_peso_standard(self):
        """Test standard price formatting"""
        assert self.service._format_colombian_peso(100000) == "$100.000"
        assert self.service._format_colombian_peso(99999) == "$99.999"
        assert self.service._format_colombian_peso(1000000) == "$1.000.000"

    def test_format_colombian_peso_edge_cases(self):
        """Test edge cases for price formatting"""
        assert self.service._format_colombian_peso(0) == "$0"
        assert self.service._format_colombian_peso(1) == "$1"
        assert self.service._format_colombian_peso(10000000) == "$10.000.000"

    def test_message_has_whatsapp_markdown_formatting(self):
        """Test that message uses WhatsApp Markdown formatting"""
        result = self.service.build_campaign_message(self.base_product)

        # Product name should be bold (wrapped in *)
        assert "*Producto de Prueba*" in result.text

    def test_message_contains_call_to_action(self):
        """Test that message includes call to action"""
        result = self.service.build_campaign_message(self.base_product)

        assert "¡Contáctanos para más información!" in result.text

    def test_campaign_message_dataclass(self):
        """Test CampaignMessage dataclass behavior"""
        msg = CampaignMessage(text="Test", media_url="http://test.com")

        assert msg.has_media() is True

        msg_no_media = CampaignMessage(text="Test")
        assert msg_no_media.has_media() is False

    def test_message_structure_has_header(self):
        """Test that message starts with the correct header"""
        result = self.service.build_campaign_message(self.base_product)
        assert result.text.startswith("🎉 ¡Nuevo Producto Disponible!")

    def test_message_without_image_has_no_image_line(self):
        """Test that message without image does not include image URL line"""
        product = {**self.base_product, "image_url": ""}
        result = self.service.build_campaign_message(product)

        assert "🖼️ Imagen:" not in result.text

    def test_message_with_image_has_image_line(self):
        """Test that message with image includes image URL line"""
        result = self.service.build_campaign_message(self.base_product)

        assert "🖼️ Imagen: https://example.com/image.jpg" in result.text

    def test_build_message_text_private_method(self):
        """Test the private _build_message_text method directly"""
        text = self.service._build_message_text(
            "Test Product",
            "Test Description",
            "$50.000",
            "https://example.com/img.jpg"
        )

        assert "*Test Product*" in text
        assert "Test Description" in text
        assert "$50.000" in text
        assert "https://example.com/img.jpg" in text
        assert "¡Contáctanos para más información!" in text

    def test_format_colombian_peso_with_float(self):
        """Test price formatting with float values (truncates decimals)"""
        assert self.service._format_colombian_peso(99999.99) == "$99.999"
        assert self.service._format_colombian_peso(100000.50) == "$100.000"

    def test_campaign_message_caption_equals_text_when_image_present(self):
        """Test that caption equals text when image is present"""
        result = self.service.build_campaign_message(self.base_product)
        assert result.caption == result.text

    def test_default_product_name_when_missing(self):
        """Test that default product name is used when productName is missing"""
        product = {"description": "Desc", "price": 1000}
        result = self.service.build_campaign_message(product)
        assert "*Producto*" in result.text

    def test_default_description_when_missing(self):
        """Test that empty description is used when description is missing"""
        product = {"productName": "Test", "price": 1000}
        result = self.service.build_campaign_message(product)
        assert isinstance(result, CampaignMessage)

    def test_default_price_when_missing(self):
        """Test that $0 is used when both price and salePrice are missing"""
        product = {"productName": "Test", "description": "Desc"}
        result = self.service.build_campaign_message(product)
        assert "$0" in result.text
