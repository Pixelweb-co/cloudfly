# Integration test for CLOUD-95: Verify marketing-agent connectivity to backend and evolution API
import os
import pytest
import requests

# Environment variables
BACKEND_URL = os.getenv("BACKEND_URL", "http://backend-api:8080")
EVOLUTION_API_URL = os.getenv("EVOLUTION_API_URL", "http://evolution-api:8080")

@pytest.mark.integration
def test_cloud95_integration():
    """
    CLOUD-95: Integration test for marketing-agent service.
    
    This test verifies:
    1. Backend API is reachable and returns 200 on /health
    2. Evolution API is reachable and returns 200 on /health
    3. Both services are accessible from within the marketing-agent container
    
    Environment: dev (local Docker Compose)
    Type: Integration test
    """
    
    # Test 1: Backend health endpoint
    backend_url = f"{BACKEND_URL}/health"
    try:
        backend_resp = requests.get(backend_url, timeout=10)
    except Exception as e:
        pytest.fail(f"Backend API unreachable at {backend_url}: {e}")
    assert backend_resp.status_code == 200, f"Backend health check failed: {backend_resp.status_code}"
    
    # Test 2: Evolution API health endpoint
    evolution_url = f"{EVOLUTION_API_URL}/health"
    try:
        evolution_resp = requests.get(evolution_url, timeout=10)
    except Exception as e:
        pytest.fail(f"Evolution API unreachable at {evolution_url}: {e}")
    assert evolution_resp.status_code == 200, f"Evolution API health check failed: {evolution_resp.status_code}"
    
    # Test 3: Confirm environment variables are set
    assert BACKEND_URL != "http://backend-api:8080", "BACKEND_URL environment variable not overridden"
    assert EVOLUTION_API_URL != "http://evolution-api:8080", "EVOLUTION_API_URL environment variable not overridden"
    
    print(f"✅ CLOUD-95 PASSED: Backend and Evolution APIs are reachable in dev environment.")