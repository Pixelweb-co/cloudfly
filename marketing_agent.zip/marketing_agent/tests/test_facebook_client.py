import unittest
import os
from unittest.mock import patch, MagicMock
from marketing_agent.facebook_client import FacebookAPIClient, FacebookAPIError

class TestFacebookAPIClient(unittest.TestCase):
    def setUp(self):
        os.environ['FB_APP_ID'] = 'app_id'
        os.environ['FB_APP_SECRET'] = 'app_secret'
        os.environ['FB_ACCESS_TOKEN'] = 'access_token'
        os.environ['FB_PAGE_ID'] = 'page_id'

    @patch('marketing_agent.facebook_client.requests.request')
    def test_get_page_info_success(self, mock_request):
        mock_resp = MagicMock()
        mock_resp.ok = True
        mock_resp.json.return_value = {'id': '123', 'name': 'Test Page'}
        mock_request.return_value = mock_resp
        client = FacebookAPIClient()
        result = client.get_page_info()
        self.assertEqual(result['id'], '123')
        mock_request.assert_called_once()

    @patch('marketing_agent.facebook_client.requests.request')
    @patch.object(FacebookAPIClient, 'refresh_token')
    def test_401_triggers_refresh(self, mock_refresh, mock_request):
        resp_401 = MagicMock()
        resp_401.ok = False
        resp_401.status_code = 401
        resp_ok = MagicMock()
        resp_ok.ok = True
        resp_ok.json.return_value = {'id': '123'}
        mock_request.side_effect = [resp_401, resp_ok]
        client = FacebookAPIClient()
        result = client.get_page_info()
        self.assertEqual(result['id'], '123')
        self.assertEqual(mock_request.call_count, 2)
        mock_refresh.assert_called_once()

    @patch('marketing_agent.facebook_client.requests.request')
    def test_publish_ad_error(self, mock_request):
        mock_resp = MagicMock()
        mock_resp.ok = False
        mock_resp.status_code = 400
        mock_resp.text = 'Bad Request'
        mock_request.return_value = mock_resp
        client = FacebookAPIClient()
        with self.assertRaises(FacebookAPIError) as ctx:
            client.publish_ad({'name': 'test'})
        self.assertIn('Facebook API error 400', str(ctx.exception))

if __name__ == '__main__':
    unittest.main()
