import os
import pytest
from marketing_agent.config import FacebookConfig


def test_facebook_config_missing(monkeypatch):
    # Ensure env vars are not set
    monkeypatch.delenv("FB_APP_ID", raising=False)
    monkeypatch.delenv("FB_APP_SECRET", raising=False)
    monkeypatch.delenv("FB_ACCESS_TOKEN", raising=False)
    cfg = FacebookConfig()
    assert not cfg.is_valid()


def test_facebook_config_present(monkeypatch):
    monkeypatch.setenv("FB_APP_ID", "123")
    monkeypatch.setenv("FB_APP_SECRET", "secret")
    monkeypatch.setenv("FB_ACCESS_TOKEN", "token")
    cfg = FacebookConfig()
    assert cfg.is_valid()
    assert cfg.api_version == "v18.0"  # default version
