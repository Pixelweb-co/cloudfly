import requests_mock
from marketing_agent.services.meta_ads_service import MetaAdsService


def test_verify_token_success(monkeypatch):
    # Set minimal env vars for the test
    monkeypatch.setenv("FB_APP_ID", "1")
    monkeypatch.setenv("FB_APP_SECRET", "2")
    monkeypatch.setenv("FB_ACCESS_TOKEN", "dummy_token")

    with requests_mock.Mocker() as m:
        m.get("https://graph.facebook.com/v18.0/me", json={"id": "123", "name": "Test"}, status_code=200)
        service = MetaAdsService()
        assert service.verify_token() is True
